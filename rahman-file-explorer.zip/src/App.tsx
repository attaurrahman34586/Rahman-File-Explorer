import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { StorageBar } from './components/StorageBar';
import { Breadcrumbs } from './components/Breadcrumbs';
import { FileList } from './components/FileList';
import { FilePreviewModal } from './components/FilePreviewModal';
import { WifiQrModal } from './components/WifiQrModal';
import { UploadModal } from './components/UploadModal';
import { ServerSettingsModal } from './components/ServerSettingsModal';
import { TransferMonitorModal } from './components/TransferMonitorModal';
import { MobileSimulatedApp } from './components/MobileSimulatedApp';
import { 
  FileItem, 
  StorageInfo, 
  ServerSettings, 
  TransferItem, 
  FileType, 
  ViewMode, 
  SortField, 
  SortOrder 
} from './types';
import { FolderPlus, Edit3, X, Check, WifiOff, Radio, AlertTriangle } from 'lucide-react';

export default function App() {
  const [currentPath, setCurrentPath] = useState('/');
  const [files, setFiles] = useState<FileItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<FileType | 'all'>('all');
  const [viewMode, setViewMode] = useState<ViewMode>('list');
  const [sortField, setSortField] = useState<SortField>('name');
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');
  const [isMobileSimMode, setIsMobileSimMode] = useState(false);

  // Modals state
  const [previewFile, setPreviewFile] = useState<FileItem | null>(null);
  const [showQrModal, setShowQrModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showTransferModal, setShowTransferModal] = useState(false);

  // Create folder / rename modals
  const [showCreateFolderModal, setShowCreateFolderModal] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [renameTarget, setRenameTarget] = useState<FileItem | null>(null);
  const [renameNewName, setRenameNewName] = useState('');

  // Default Storage & Server state
  const [storage, setStorage] = useState<StorageInfo>({
    totalBytes: 64 * 1024 * 1024 * 1024,
    usedBytes: 28.4 * 1024 * 1024 * 1024,
    freeBytes: 35.6 * 1024 * 1024 * 1024,
    categories: {
      images: 12.2 * 1024 * 1024 * 1024,
      videos: 9.8 * 1024 * 1024 * 1024,
      audio: 3.4 * 1024 * 1024 * 1024,
      documents: 1.2 * 1024 * 1024 * 1024,
      archives: 1.1 * 1024 * 1024 * 1024,
      apps: 0.7 * 1024 * 1024 * 1024,
      others: 0,
    }
  });

  const [settings, setSettings] = useState<ServerSettings>({
    ssid: 'AndroidAP_Hotspot',
    ipAddress: '192.168.43.1',
    hotspotIp: '192.168.43.1',
    wifiIp: '192.168.1.105',
    port: 8888,
    isServerRunning: true,
    autoStartOnLaunch: true,
    hotspotActive: true,
    connectionType: 'hotspot',
    pinProtected: false,
    pinCode: '1234',
    readOnly: false,
    activeClients: 3,
    maxUploadSizeMb: 500,
  });

  // Heartbeat to keep server active while app is running, and close on exit
  useEffect(() => {
    const sendHeartbeat = async () => {
      try {
        const res = await fetch('/api/heartbeat', { method: 'POST' });
        if (res.ok) {
          const data = await res.json();
          if (data.isServerRunning !== undefined) {
            setSettings(prev => ({ 
              ...prev, 
              isServerRunning: data.isServerRunning,
              hotspotActive: data.hotspotActive !== undefined ? data.hotspotActive : prev.hotspotActive
            }));
          }
        }
      } catch {
        // ignore
      }
    };

    sendHeartbeat();
    const heartbeatInterval = setInterval(sendHeartbeat, 3000);

    const handleBeforeUnload = () => {
      navigator.sendBeacon('/api/app-close');
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      clearInterval(heartbeatInterval);
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, []);

  const [transfers, setTransfers] = useState<TransferItem[]>([]);

  // Fetch directory files from backend API
  const fetchFiles = async (pathStr: string) => {
    try {
      const res = await fetch(`/api/files?path=${encodeURIComponent(pathStr)}`);
      if (res.ok) {
        const data = await res.json();
        setFiles(data.files || []);
        setCurrentPath(data.currentPath || pathStr);
      }
    } catch {
      // ignore or fallback
    }
  };

  // Search API call
  const fetchSearchResults = async (query: string) => {
    try {
      const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
      if (res.ok) {
        const data = await res.json();
        setFiles(data.results || []);
      }
    } catch {
      // ignore
    }
  };

  // Status & Settings API call
  const fetchStatus = async () => {
    try {
      const res = await fetch('/api/status');
      if (res.ok) {
        const data = await res.json();
        if (data.settings) setSettings(data.settings);
        if (data.storage) setStorage(data.storage);
      }
    } catch {
      // ignore
    }
  };

  // Fetch transfers
  const fetchTransfers = async () => {
    try {
      const res = await fetch('/api/transfers');
      if (res.ok) {
        const data = await res.json();
        setTransfers(data.transfers || []);
      }
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    fetchStatus();
    fetchTransfers();
  }, []);

  useEffect(() => {
    setSelectedIds([]);
    if (searchQuery.trim()) {
      fetchSearchResults(searchQuery);
    } else {
      fetchFiles(currentPath);
    }
  }, [currentPath, searchQuery]);

  // Category Filtering & Sorting logic
  const filteredFiles = files.filter((f) => {
    if (activeCategoryFilter === 'all') return true;
    return f.type === activeCategoryFilter;
  });

  const sortedFiles = [...filteredFiles].sort((a, b) => {
    let comparison = 0;
    if (sortField === 'name') {
      comparison = a.name.localeCompare(b.name);
    } else if (sortField === 'size') {
      comparison = a.size - b.size;
    } else if (sortField === 'modified') {
      comparison = new Date(a.modified).getTime() - new Date(b.modified).getTime();
    } else if (sortField === 'type') {
      comparison = a.type.localeCompare(b.type);
    }
    return sortOrder === 'asc' ? comparison : -comparison;
  });

  // Action handlers
  const handleToggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleToggleSelectAll = () => {
    if (selectedIds.length === sortedFiles.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(sortedFiles.map((f) => f.id));
    }
  };

  const handleCreateFolder = async () => {
    if (!newFolderName.trim()) return;
    try {
      const res = await fetch('/api/folder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          currentPath,
          folderName: newFolderName.trim(),
        }),
      });
      if (res.ok) {
        setNewFolderName('');
        setShowCreateFolderModal(false);
        fetchFiles(currentPath);
      }
    } catch {
      // ignore
    }
  };

  const handleRename = async () => {
    if (!renameTarget || !renameNewName.trim()) return;
    try {
      const oldRelPath = `${renameTarget.path}/${renameTarget.name}`;
      const res = await fetch('/api/rename', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          oldRelPath,
          newName: renameNewName.trim(),
        }),
      });
      if (res.ok) {
        setRenameTarget(null);
        setRenameNewName('');
        fetchFiles(currentPath);
      }
    } catch {
      // ignore
    }
  };

  const handleDeleteItem = async (file: FileItem) => {
    if (!confirm(`Are you sure you want to delete "${file.name}"?`)) return;
    try {
      const relPath = `${file.path}/${file.name}`;
      const res = await fetch('/api/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items: [relPath] }),
      });
      if (res.ok) {
        fetchFiles(currentPath);
      }
    } catch {
      // ignore
    }
  };

  const handleBatchDelete = async () => {
    const itemsToDelete = files
      .filter((f) => selectedIds.includes(f.id))
      .map((f) => `${f.path}/${f.name}`);

    if (itemsToDelete.length === 0) return;
    if (!confirm(`Delete ${itemsToDelete.length} selected items?`)) return;

    try {
      const res = await fetch('/api/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items: itemsToDelete }),
      });
      if (res.ok) {
        setSelectedIds([]);
        fetchFiles(currentPath);
      }
    } catch {
      // ignore
    }
  };

  const handleBatchDownload = () => {
    const selectedFilesList = files.filter((f) => selectedIds.includes(f.id));
    selectedFilesList.forEach((file) => {
      window.open(`/api/download?path=${encodeURIComponent(`${file.path}/${file.name}`)}`, '_blank');
    });
  };

  const handleDownloadSingle = (file: FileItem) => {
    window.open(`/api/download?path=${encodeURIComponent(`${file.path}/${file.name}`)}`, '_blank');
  };

  const handleUpdateSettings = async (newSettings: Partial<ServerSettings>) => {
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newSettings),
      });
      if (res.ok) {
        const data = await res.json();
        setSettings(data.settings);
      }
    } catch {
      // ignore
    }
  };

  const handleDropFiles = (droppedFiles: FileList) => {
    setShowUploadModal(true);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      
      {/* Top Header */}
      <Header
        settings={settings}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onOpenQrModal={() => setShowQrModal(true)}
        onOpenSettingsModal={() => setShowSettingsModal(true)}
        onOpenTransferModal={() => setShowTransferModal(true)}
        isMobileSimMode={isMobileSimMode}
        onToggleMobileSimMode={() => setIsMobileSimMode(!isMobileSimMode)}
      />

      {/* Hotspot Offline Warning Banner */}
      {(!settings.hotspotActive || !settings.isServerRunning) && (
        <div className="bg-amber-500/10 border-y border-amber-500/30 px-4 py-3">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-amber-300">
            <div className="flex items-center gap-2">
              <WifiOff className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                <strong>Hotspot Disconnected:</strong> Mobile Hotspot is required to serve files wirelessly. Turn ON Hotspot to resume serving on port <strong>8888</strong>.
              </span>
            </div>
            <button
              onClick={() => handleUpdateSettings({ hotspotActive: true, isServerRunning: true })}
              className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg transition shrink-0"
            >
              Turn ON Hotspot
            </button>
          </div>
        </div>
      )}

      {/* Main Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-4">
        
        {isMobileSimMode ? (
          /* Mobile Phone App Mode */
          <MobileSimulatedApp
            settings={settings}
            storage={storage}
            onUpdateSettings={handleUpdateSettings}
            onOpenQrModal={() => setShowQrModal(true)}
            onOpenWebExplorer={() => setIsMobileSimMode(false)}
          />
        ) : (
          /* Desktop Web Explorer Mode */
          <>
            {/* Storage Bar */}
            <StorageBar
              storage={storage}
              activeCategoryFilter={activeCategoryFilter}
              onSelectCategory={setActiveCategoryFilter}
            />

            {/* Breadcrumb Path & Action Toolbar */}
            <Breadcrumbs
              currentPath={currentPath}
              onNavigatePath={(p) => {
                setSearchQuery('');
                setCurrentPath(p);
              }}
              onOpenCreateFolder={() => setShowCreateFolderModal(true)}
              onOpenUpload={() => setShowUploadModal(true)}
              selectedCount={selectedIds.length}
              totalCount={sortedFiles.length}
              isAllSelected={selectedIds.length === sortedFiles.length && sortedFiles.length > 0}
              onToggleSelectAll={handleToggleSelectAll}
              onBatchDelete={handleBatchDelete}
              onBatchDownload={handleBatchDownload}
              viewMode={viewMode}
              onChangeViewMode={setViewMode}
              sortField={sortField}
              sortOrder={sortOrder}
              onChangeSort={(field) => {
                if (sortField === field) {
                  setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
                } else {
                  setSortField(field);
                  setSortOrder('asc');
                }
              }}
              isReadOnly={settings.readOnly}
            />

            {/* File List / Grid */}
            <FileList
              files={sortedFiles}
              selectedIds={selectedIds}
              onToggleSelect={handleToggleSelect}
              onOpenFolder={(folderPath) => {
                setSearchQuery('');
                setCurrentPath(folderPath);
              }}
              onPreviewFile={(f) => setPreviewFile(f)}
              onDownloadFile={handleDownloadSingle}
              onRenameFile={(f) => {
                setRenameTarget(f);
                setRenameNewName(f.name);
              }}
              onDeleteFile={handleDeleteItem}
              viewMode={viewMode}
              isReadOnly={settings.readOnly}
              onDropFiles={handleDropFiles}
            />
          </>
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Rahman File Explorer Pro • Hotspot Wireless Web Server</span>
          <span>Status: <strong className={settings.hotspotActive && settings.isServerRunning ? "text-emerald-400" : "text-amber-400"}>{settings.hotspotActive && settings.isServerRunning ? "Active (Hotspot ON)" : "Paused (Hotspot Required)"}</strong> (Port {settings.port})</span>
        </div>
      </footer>

      {/* MODALS */}

      {/* File Previewer */}
      {previewFile && (
        <FilePreviewModal
          file={previewFile}
          onClose={() => setPreviewFile(null)}
          onDownload={handleDownloadSingle}
        />
      )}

      {/* QR Code Modal */}
      {showQrModal && (
        <WifiQrModal
          settings={settings}
          onClose={() => setShowQrModal(false)}
        />
      )}

      {/* Upload Modal */}
      {showUploadModal && (
        <UploadModal
          currentPath={currentPath}
          onClose={() => setShowUploadModal(false)}
          onUploadSuccess={() => fetchFiles(currentPath)}
          isReadOnly={settings.readOnly}
        />
      )}

      {/* Server Settings Modal */}
      {showSettingsModal && (
        <ServerSettingsModal
          settings={settings}
          onClose={() => setShowSettingsModal(false)}
          onUpdateSettings={handleUpdateSettings}
        />
      )}

      {/* Transfer Monitor Modal */}
      {showTransferModal && (
        <TransferMonitorModal
          transfers={transfers}
          onClose={() => setShowTransferModal(false)}
          onRefresh={fetchTransfers}
        />
      )}

      {/* Create New Folder Modal */}
      {showCreateFolderModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 text-white rounded-2xl w-full max-w-sm p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <FolderPlus className="w-5 h-5 text-amber-500" />
                <h3 className="text-sm font-bold">Create New Folder</h3>
              </div>
              <button onClick={() => setShowCreateFolderModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <label className="text-xs text-slate-400 mb-1 block">Folder Name:</label>
              <input
                type="text"
                autoFocus
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                placeholder="e.g. Work Documents"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowCreateFolderModal(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateFolder}
                className="px-4 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-md"
              >
                Create Folder
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Rename Modal */}
      {renameTarget && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 text-white rounded-2xl w-full max-w-sm p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-amber-500" />
                <h3 className="text-sm font-bold">Rename Item</h3>
              </div>
              <button onClick={() => setRenameTarget(null)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <label className="text-xs text-slate-400 mb-1 block">New Name:</label>
              <input
                type="text"
                autoFocus
                value={renameNewName}
                onChange={(e) => setRenameNewName(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setRenameTarget(null)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleRename}
                className="px-4 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-md"
              >
                Rename
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
