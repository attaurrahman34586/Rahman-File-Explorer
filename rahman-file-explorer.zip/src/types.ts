export type FileType = 'folder' | 'image' | 'video' | 'audio' | 'document' | 'archive' | 'app' | 'text' | 'code';

export interface FileItem {
  id: string;
  name: string;
  path: string; // e.g. "/Pictures/Vacation"
  type: FileType;
  size: number; // in bytes
  modified: string; // ISO date string
  extension?: string;
  mimeType?: string;
  contentUrl?: string;
  thumbnailUrl?: string;
  // For audio/video
  duration?: number; // in seconds
  artist?: string;
  album?: string;
  // For images
  dimensions?: string; // e.g. "1920x1080"
  // For apps
  version?: string;
  packageName?: string;
  // For text/code
  textContent?: string;
}

export interface CategoryStats {
  id: FileType | 'all';
  label: string;
  icon: string;
  count: number;
  totalSize: number; // bytes
  color: string;
}

export interface StorageInfo {
  totalBytes: number;
  usedBytes: number;
  freeBytes: number;
  categories: {
    images: number;
    videos: number;
    audio: number;
    documents: number;
    archives: number;
    apps: number;
    others: number;
  };
}

export interface ServerSettings {
  ssid: string;
  ipAddress: string;
  port: number;
  isServerRunning: boolean;
  hotspotActive: boolean;
  pinProtected: boolean;
  pinCode: string;
  readOnly: boolean;
  activeClients: number;
  maxUploadSizeMb: number;
  connectionType: 'hotspot' | 'wifi' | 'auto';
  hotspotIp: string;
  wifiIp: string;
  autoStartOnLaunch: boolean;
}

export interface TransferItem {
  id: string;
  filename: string;
  size: number;
  bytesTransferred: number;
  speedKbps: number;
  type: 'upload' | 'download';
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  clientIp: string;
  startTime: string;
}

export type ViewMode = 'grid' | 'list' | 'compact';
export type SortField = 'name' | 'size' | 'modified' | 'type';
export type SortOrder = 'asc' | 'desc';
