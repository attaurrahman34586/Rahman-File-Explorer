import React, { useState } from 'react';
import { 
  X, 
  Settings, 
  Wifi, 
  Lock, 
  Eye, 
  Save, 
  Flame,
  Zap,
  Users,
  Download
} from 'lucide-react';
import { ServerSettings } from '../types';

interface ServerSettingsModalProps {
  settings: ServerSettings;
  onClose: () => void;
  onUpdateSettings: (newSettings: Partial<ServerSettings>) => void;
}

export const ServerSettingsModal: React.FC<ServerSettingsModalProps> = ({
  settings,
  onClose,
  onUpdateSettings,
}) => {
  const [ssid, setSsid] = useState(settings.ssid);
  const [hotspotActive, setHotspotActive] = useState(settings.hotspotActive !== undefined ? settings.hotspotActive : true);
  const [pinProtected, setPinProtected] = useState(settings.pinProtected);
  const [pinCode, setPinCode] = useState(settings.pinCode);
  const [readOnly, setReadOnly] = useState(settings.readOnly);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    onUpdateSettings({
      ssid,
      hotspotActive,
      isServerRunning: hotspotActive,
      pinProtected,
      pinCode,
      readOnly,
      port: 8888,
    });
    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-slate-900 border border-slate-800 text-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-900">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-100">Rahman File Explorer Settings</h2>
              <p className="text-xs text-slate-400">Configure Wi-Fi hotspot & security options</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4">
          
          {/* Auto-Start Banner */}
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-slate-200 font-medium">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>Auto-Start Status:</span>
              <strong className="text-emerald-400 font-bold">Starts Automatically on Launch</strong>
            </div>
            <span className="text-[10px] bg-cyan-500/10 text-cyan-300 font-mono font-bold px-2 py-0.5 rounded border border-cyan-500/30">
              Port 8888
            </span>
          </div>

          {/* Hotspot Toggle */}
          <div className="flex items-center justify-between p-3.5 bg-slate-950 rounded-xl border border-slate-800">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-xl ${hotspotActive ? 'bg-orange-500/20 text-orange-400' : 'bg-slate-800 text-slate-500'}`}>
                <Flame className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-200">Mobile Hotspot Requirement</h4>
                <p className="text-[11px] text-slate-400">
                  {hotspotActive ? 'Hotspot is active for wireless web serving' : 'Hotspot is turned OFF'}
                </p>
              </div>
            </div>

            <button
              onClick={() => setHotspotActive(!hotspotActive)}
              className={`px-3 py-1.5 text-xs font-bold rounded-xl transition ${
                hotspotActive 
                  ? 'bg-orange-500 text-slate-950 hover:bg-orange-400' 
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {hotspotActive ? 'HOTSPOT ON' : 'DISABLED'}
            </button>
          </div>

          {/* Wi-Fi SSID Name */}
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <Wifi className="w-3.5 h-3.5 text-cyan-400" />
              <span>Hotspot SSID Network Name</span>
            </label>
            <input
              type="text"
              value={ssid}
              onChange={(e) => setSsid(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono text-cyan-300 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Security PIN Option */}
          <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Lock className="w-4 h-4 text-amber-400" />
                <div>
                  <h4 className="text-xs font-bold text-slate-200">Require Access PIN Code</h4>
                  <p className="text-[10px] text-slate-400">Prompts browsers for a password to browse files</p>
                </div>
              </div>

              <input
                type="checkbox"
                checked={pinProtected}
                onChange={(e) => setPinProtected(e.target.checked)}
                className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
              />
            </div>

            {pinProtected && (
              <div className="pt-2 border-t border-slate-900 flex items-center justify-between">
                <span className="text-xs text-slate-400">4-Digit Security PIN:</span>
                <input
                  type="text"
                  maxLength={6}
                  value={pinCode}
                  onChange={(e) => setPinCode(e.target.value)}
                  className="w-24 text-center px-2 py-1 bg-slate-900 border border-slate-700 rounded-lg text-xs font-mono font-bold text-amber-400 focus:outline-none focus:border-amber-400"
                />
              </div>
            )}
          </div>

          {/* Read-Only Mode Toggle */}
          <div className="flex items-center justify-between p-3.5 bg-slate-950 rounded-xl border border-slate-800">
            <div className="flex items-center gap-2.5">
              <Eye className="w-4 h-4 text-blue-400" />
              <div>
                <h4 className="text-xs font-bold text-slate-200">Read-Only Mode</h4>
                <p className="text-[10px] text-slate-400">Disables upload, delete, and rename from browsers</p>
              </div>
            </div>

            <input
              type="checkbox"
              checked={readOnly}
              onChange={(e) => setReadOnly(e.target.checked)}
              className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
            />
          </div>

          {/* Connected Devices Overview */}
          <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-400" />
              <span>Active Connected Devices:</span>
            </div>
            <strong className="text-emerald-400 font-bold">{settings.activeClients} Devices</strong>
          </div>

          {/* Download Source Code ZIP */}
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs text-slate-300">
              <Download className="w-4 h-4 text-cyan-400" />
              <div>
                <span className="font-bold text-slate-200">App Source Code (ZIP)</span>
                <p className="text-[10px] text-slate-400">Download project files as ZIP archive</p>
              </div>
            </div>
            <a
              href="/rahman-file-explorer.zip"
              download="rahman-file-explorer.zip"
              className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs rounded-lg transition flex items-center gap-1 shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download ZIP</span>
            </a>
          </div>

        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white transition"
          >
            Cancel
          </button>

          <button
            onClick={handleSave}
            className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-lg shadow-cyan-600/20 transition"
          >
            <Save className="w-4 h-4" />
            <span>{isSaved ? 'Saved!' : 'Save Settings'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
