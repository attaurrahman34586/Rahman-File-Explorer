import React from 'react';
import { X, Activity, ArrowUpRight, ArrowDownLeft, CheckCircle, Clock, HardDrive, RefreshCw } from 'lucide-react';
import { TransferItem } from '../types';
import { formatBytes, formatSpeed, formatDate } from '../utils/formatters';

interface TransferMonitorModalProps {
  transfers: TransferItem[];
  onClose: () => void;
  onRefresh: () => void;
}

export const TransferMonitorModal: React.FC<TransferMonitorModalProps> = ({
  transfers,
  onClose,
  onRefresh,
}) => {
  const totalUploaded = transfers
    .filter((t) => t.type === 'upload')
    .reduce((acc, t) => acc + t.bytesTransferred, 0);

  const totalDownloaded = transfers
    .filter((t) => t.type === 'download')
    .reduce((acc, t) => acc + t.bytesTransferred, 0);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-slate-900 border border-slate-800 text-white rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-900">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-100">Wi-Fi Transfer Monitor</h2>
              <p className="text-xs text-slate-400">Real-time bandwidth & transfer logs</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onRefresh}
              className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
              title="Refresh Transfers"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Speed Stats Banner */}
        <div className="p-4 grid grid-cols-2 sm:grid-cols-3 gap-3 bg-slate-950 border-b border-slate-800">
          <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400">
              <ArrowDownLeft className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase">Total Downloaded</span>
              <p className="text-sm font-bold font-mono text-emerald-400">{formatBytes(totalDownloaded)}</p>
            </div>
          </div>

          <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-cyan-500/20 text-cyan-400">
              <ArrowUpRight className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase">Total Uploaded</span>
              <p className="text-sm font-bold font-mono text-cyan-400">{formatBytes(totalUploaded)}</p>
            </div>
          </div>

          <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center gap-3 col-span-2 sm:col-span-1">
            <div className="p-2 rounded-lg bg-purple-500/20 text-purple-400">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase">Wi-Fi Speed Peak</span>
              <p className="text-sm font-bold font-mono text-purple-300">12.5 MB/s</p>
            </div>
          </div>
        </div>

        {/* Transfer History Table */}
        <div className="flex-1 overflow-y-auto p-4">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
            Recent Transfer History
          </h3>

          {transfers.length === 0 ? (
            <div className="text-center py-10 text-slate-500 text-xs">
              No recent transfers logged.
            </div>
          ) : (
            <div className="space-y-2">
              {transfers.map((t) => (
                <div
                  key={t.id}
                  className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-3 truncate pr-2">
                    <div className={`p-2 rounded-xl shrink-0 ${
                      t.type === 'upload' ? 'bg-cyan-500/10 text-cyan-400' : 'bg-emerald-500/10 text-emerald-400'
                    }`}>
                      {t.type === 'upload' ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownLeft className="w-4 h-4" />}
                    </div>

                    <div className="truncate">
                      <h4 className="font-semibold text-slate-200 truncate">{t.filename}</h4>
                      <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                        <span className="font-mono">{formatBytes(t.size)}</span>
                        <span>•</span>
                        <span>IP: {t.clientIp}</span>
                        <span>•</span>
                        <span>{formatDate(t.startTime)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="font-mono font-bold text-cyan-300 block">
                      {formatSpeed(t.speedKbps)}
                    </span>
                    <span className="inline-flex items-center gap-1 text-[10px] text-emerald-400 font-semibold mt-0.5">
                      <CheckCircle className="w-3 h-3" />
                      <span>{t.status}</span>
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950 text-right">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
