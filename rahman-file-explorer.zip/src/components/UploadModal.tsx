import React, { useState } from 'react';
import { X, Upload, FileUp, CheckCircle, AlertCircle, HardDrive } from 'lucide-react';
import { formatBytes } from '../utils/formatters';

interface UploadModalProps {
  currentPath: string;
  onClose: () => void;
  onUploadSuccess: () => void;
  isReadOnly: boolean;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  currentPath,
  onClose,
  onUploadSuccess,
  isReadOnly,
}) => {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFiles(Array.from(e.target.files));
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      setSelectedFiles(Array.from(e.dataTransfer.files));
    }
  };

  const startUpload = async () => {
    if (selectedFiles.length === 0) return;
    if (isReadOnly) {
      setUploadStatus('Error: Server is in Read-Only mode');
      return;
    }

    setIsUploading(true);
    setUploadProgress(15);
    setUploadStatus('Transferring files over Wi-Fi network...');

    try {
      const formData = new FormData();
      selectedFiles.forEach((file) => {
        formData.append('files', file);
      });

      // Simulate progressive upload steps
      const interval = setInterval(() => {
        setUploadProgress((prev) => {
          if (prev >= 90) {
            clearInterval(interval);
            return 90;
          }
          return prev + 25;
        });
      }, 200);

      const res = await fetch(`/api/upload?path=${encodeURIComponent(currentPath)}`, {
        method: 'POST',
        body: formData,
      });

      clearInterval(interval);

      if (res.ok) {
        setUploadProgress(100);
        setUploadStatus('Files uploaded successfully!');
        setTimeout(() => {
          onUploadSuccess();
          onClose();
        }, 1200);
      } else {
        const data = await res.json();
        setUploadStatus(data.error || 'Upload failed');
        setIsUploading(false);
      }
    } catch (err: any) {
      setUploadStatus(err.message || 'Error uploading files');
      setIsUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-slate-900 border border-slate-800 text-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-900">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-100">Upload Files over Wi-Fi</h2>
              <p className="text-xs text-slate-400">Destination: <code className="text-cyan-300 font-mono">{currentPath}</code></p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isUploading}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition disabled:opacity-50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drag & Drop Area */}
        <div className="p-5">
          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
            className="border-2 border-dashed border-slate-700 hover:border-cyan-500 bg-slate-950/50 rounded-2xl p-6 text-center transition flex flex-col items-center justify-center cursor-pointer"
            onClick={() => document.getElementById('file-upload-input')?.click()}
          >
            <FileUp className="w-12 h-12 text-cyan-400 mb-2 animate-pulse" />
            <p className="text-sm font-semibold text-slate-200">
              Drag & Drop files here, or <span className="text-cyan-400 underline">Browse Files</span>
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Supports photos, videos, music, documents, zip archives, and APKs
            </p>
            <input
              id="file-upload-input"
              type="file"
              multiple
              onChange={handleFileChange}
              className="hidden"
            />
          </div>

          {/* Selected File List */}
          {selectedFiles.length > 0 && (
            <div className="mt-4 space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
                <span>Selected Queue ({selectedFiles.length} files):</span>
                <span>
                  Total: {formatBytes(selectedFiles.reduce((acc, f) => acc + f.size, 0))}
                </span>
              </div>

              <div className="max-h-40 overflow-y-auto space-y-1.5 pr-1">
                {selectedFiles.map((file, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-2 rounded-xl bg-slate-950 border border-slate-800 text-xs"
                  >
                    <div className="flex items-center gap-2 truncate pr-2">
                      <HardDrive className="w-4 h-4 text-cyan-400 shrink-0" />
                      <span className="truncate text-slate-200 font-medium">{file.name}</span>
                    </div>
                    <span className="font-mono text-slate-400 shrink-0">{formatBytes(file.size)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Upload Progress Bar */}
          {isUploading && (
            <div className="mt-4 p-3 bg-slate-950 rounded-xl border border-slate-800">
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="text-cyan-300 font-semibold">{uploadStatus}</span>
                <span className="font-mono font-bold text-white">{uploadProgress}%</span>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
            </div>
          )}

          {uploadStatus && !isUploading && (
            <div className={`mt-3 p-2.5 rounded-xl text-xs flex items-center gap-2 ${
              uploadStatus.includes('successfully') 
                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
            }`}>
              {uploadStatus.includes('successfully') ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
              <span>{uploadStatus}</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
          <button
            onClick={onClose}
            disabled={isUploading}
            className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white transition"
          >
            Cancel
          </button>

          <button
            onClick={startUpload}
            disabled={selectedFiles.length === 0 || isUploading}
            className="flex items-center gap-2 px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-lg shadow-cyan-600/20 transition disabled:opacity-50"
          >
            <Upload className="w-4 h-4" />
            <span>{isUploading ? 'Uploading...' : 'Start Transfer'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
