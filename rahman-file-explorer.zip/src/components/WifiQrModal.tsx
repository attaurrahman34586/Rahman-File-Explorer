import React, { useState } from 'react';
import { X, Wifi, Copy, Check, QrCode, Globe, ShieldCheck, Smartphone } from 'lucide-react';
import { ServerSettings } from '../types';

interface WifiQrModalProps {
  settings: ServerSettings;
  onClose: () => void;
}

export const WifiQrModal: React.FC<WifiQrModalProps> = ({ settings, onClose }) => {
  const [copied, setCopied] = useState(false);
  const serverUrl = `http://${settings.ipAddress}:${settings.port}`;

  const copyUrlToClipboard = () => {
    navigator.clipboard.writeText(serverUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-slate-900 border border-slate-800 text-white rounded-2xl w-full max-w-md shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-900">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-100">Wi-Fi Connection QR Code</h2>
              <p className="text-xs text-slate-400">Connect mobile devices wirelessly</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 flex flex-col items-center text-center">
          
          {/* SVG QR Code Simulation */}
          <div className="p-4 bg-white rounded-2xl shadow-xl border border-slate-200 mb-4 flex flex-col items-center">
            <div className="w-48 h-48 relative flex items-center justify-center bg-slate-950 rounded-xl p-2">
              {/* Dynamic SVG QR Pattern representation */}
              <svg viewBox="0 0 100 100" className="w-full h-full text-white fill-current">
                {/* Outer corners */}
                <path d="M 5 5 H 35 V 35 H 5 Z M 10 10 V 30 H 30 V 10 Z M 15 15 H 25 V 25 H 15 Z" />
                <path d="M 65 5 H 95 V 35 H 65 Z M 70 10 V 30 H 90 V 10 Z M 75 15 H 85 V 25 H 75 Z" />
                <path d="M 5 65 H 35 V 95 H 5 Z M 10 70 V 90 H 30 V 70 Z M 15 75 H 25 V 85 H 15 Z" />
                {/* Simulated Data matrix dots */}
                <rect x="42" y="10" width="6" height="6" />
                <rect x="52" y="10" width="6" height="6" />
                <rect x="42" y="22" width="6" height="6" />
                <rect x="42" y="34" width="6" height="6" />
                <rect x="52" y="28" width="6" height="6" />
                <rect x="10" y="42" width="6" height="6" />
                <rect x="22" y="42" width="6" height="6" />
                <rect x="34" y="42" width="6" height="6" />
                <rect x="10" y="52" width="6" height="6" />
                <rect x="28" y="52" width="6" height="6" />
                <rect x="42" y="42" width="16" height="16" rx="3" className="fill-cyan-400" />
                <rect x="65" y="42" width="6" height="6" />
                <rect x="77" y="42" width="6" height="6" />
                <rect x="89" y="42" width="6" height="6" />
                <rect x="65" y="52" width="6" height="6" />
                <rect x="83" y="52" width="6" height="6" />
                <rect x="42" y="65" width="6" height="6" />
                <rect x="52" y="65" width="6" height="6" />
                <rect x="42" y="77" width="6" height="6" />
                <rect x="52" y="89" width="6" height="6" />
                <rect x="65" y="65" width="6" height="6" />
                <rect x="77" y="77" width="6" height="6" />
                <rect x="89" y="89" width="6" height="6" />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-10 h-10 rounded-xl bg-slate-900 border-2 border-cyan-400 flex items-center justify-center text-cyan-400 shadow-lg">
                  <Wifi className="w-5 h-5" />
                </div>
              </div>
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 mt-2">
              Scan with Phone Camera
            </span>
          </div>

          {/* Wi-Fi Details Card */}
          <div className="w-full bg-slate-950 p-3.5 rounded-xl border border-slate-800 text-left space-y-2 mb-4 text-xs">
            <div className="flex items-center justify-between text-slate-300">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Wifi className="w-3.5 h-3.5 text-cyan-400" />
                Wi-Fi Network:
              </span>
              <strong className="text-white">{settings.ssid}</strong>
            </div>

            <div className="flex items-center justify-between text-slate-300">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-cyan-400" />
                Web Server URL:
              </span>
              <div className="flex items-center gap-1">
                <code className="text-cyan-300 font-bold">{serverUrl}</code>
                <button
                  onClick={copyUrlToClipboard}
                  className="p-1 hover:text-white text-slate-400 transition"
                  title="Copy URL"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {settings.pinProtected && (
              <div className="flex items-center justify-between text-amber-400 border-t border-slate-900 pt-2">
                <span className="flex items-center gap-1.5 text-slate-400">
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                  Access PIN Code:
                </span>
                <strong className="font-mono bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                  {settings.pinCode}
                </strong>
              </div>
            )}
          </div>

          {/* Quick Setup Instructions */}
          <div className="text-left text-xs text-slate-400 space-y-1.5 bg-slate-800/40 p-3 rounded-xl border border-slate-800">
            <div className="font-semibold text-slate-300 flex items-center gap-1">
              <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
              <span>How to connect from phone / tablet:</span>
            </div>
            <ol className="list-decimal list-inside space-y-1 text-slate-400 text-[11px] pl-1">
              <li>Ensure mobile phone is on the same Wi-Fi network (<strong>{settings.ssid}</strong>).</li>
              <li>Open Phone Camera or QR scanner app and point at the QR code above.</li>
              <li>Tap the popup web link to browse, stream, or upload files wirelessly!</li>
            </ol>
          </div>

        </div>

      </div>
    </div>
  );
};
