import React, { useState } from 'react';
import { 
  X, 
  Download, 
  Image as ImageIcon, 
  Music, 
  Film, 
  FileText, 
  Smartphone, 
  Code, 
  Copy, 
  Check, 
  RotateCw, 
  ZoomIn, 
  ZoomOut,
  Play,
  Pause,
  Volume2,
  Calendar,
  HardDrive
} from 'lucide-react';
import { FileItem } from '../types';
import { formatBytes, formatDate } from '../utils/formatters';

interface FilePreviewModalProps {
  file: FileItem | null;
  onClose: () => void;
  onDownload: (file: FileItem) => void;
}

export const FilePreviewModal: React.FC<FilePreviewModalProps> = ({
  file,
  onClose,
  onDownload,
}) => {
  const [copiedText, setCopiedText] = useState(false);
  const [imgRotation, setImgRotation] = useState(0);
  const [imgZoom, setImgZoom] = useState(1);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  if (!file) return null;

  const copyTextToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  const renderContent = () => {
    switch (file.type) {
      case 'image':
        return (
          <div className="flex flex-col items-center justify-center p-4 min-h-[300px]">
            <div className="flex items-center gap-2 mb-3 bg-slate-800/80 p-1.5 rounded-xl border border-slate-700">
              <button
                onClick={() => setImgZoom(Math.min(imgZoom + 0.25, 2.5))}
                className="p-1.5 text-slate-300 hover:text-white rounded-lg hover:bg-slate-700 transition"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                onClick={() => setImgZoom(Math.max(imgZoom - 0.25, 0.5))}
                className="p-1.5 text-slate-300 hover:text-white rounded-lg hover:bg-slate-700 transition"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <button
                onClick={() => setImgRotation((imgRotation + 90) % 360)}
                className="p-1.5 text-slate-300 hover:text-white rounded-lg hover:bg-slate-700 transition"
                title="Rotate"
              >
                <RotateCw className="w-4 h-4" />
              </button>
            </div>

            <div className="overflow-hidden max-h-[60vh] flex items-center justify-center p-2">
              <div 
                className="transition-transform duration-300 bg-slate-950 rounded-xl p-2 border border-slate-800 shadow-xl"
                style={{
                  transform: `scale(${imgZoom}) rotate(${imgRotation}deg)`
                }}
              >
                {/* Fallback generated visual image canvas if direct image link is demo */}
                <div className="relative w-full max-w-lg h-72 rounded-lg bg-gradient-to-tr from-cyan-900 via-slate-900 to-indigo-900 flex flex-col items-center justify-center text-slate-200">
                  <ImageIcon className="w-20 h-20 text-cyan-400 mb-2 opacity-80" />
                  <p className="font-bold text-sm">{file.name}</p>
                  <p className="text-xs text-cyan-300 mt-1">Resolution: {file.dimensions || '1920x1080'}</p>
                </div>
              </div>
            </div>
          </div>
        );

      case 'audio':
        return (
          <div className="p-6 flex flex-col items-center justify-center">
            <div className="w-28 h-28 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-xl shadow-emerald-500/20 mb-4 animate-pulse">
              <Music className="w-12 h-12" />
            </div>

            <h3 className="text-base font-bold text-slate-100 text-center">{file.name}</h3>
            <p className="text-xs text-slate-400 mt-1">{file.artist || 'Wi-Fi Audio Stream'}</p>

            {/* Audio Wave Visualizer Simulation */}
            <div className="flex items-center gap-1 my-6 h-10">
              {[40, 70, 25, 90, 60, 30, 85, 50, 95, 45, 80, 35, 65, 90, 40].map((h, i) => (
                <div
                  key={i}
                  className={`w-1.5 bg-emerald-400 rounded-full transition-all duration-300 ${
                    isPlayingAudio ? 'animate-bounce' : ''
                  }`}
                  style={{
                    height: `${isPlayingAudio ? Math.max(15, (h * Math.random()) + 10) : h}%`,
                    animationDelay: `${i * 0.08}s`
                  }}
                />
              ))}
            </div>

            {/* Controls */}
            <div className="flex items-center gap-4 bg-slate-950 px-6 py-3 rounded-2xl border border-slate-800">
              <button
                onClick={() => setIsPlayingAudio(!isPlayingAudio)}
                className="w-12 h-12 rounded-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 flex items-center justify-center font-bold shadow-lg transition"
              >
                {isPlayingAudio ? <Pause className="w-6 h-6 fill-slate-950" /> : <Play className="w-6 h-6 fill-slate-950 ml-0.5" />}
              </button>
              <div className="flex items-center gap-2 text-slate-400">
                <Volume2 className="w-5 h-5 text-emerald-400" />
                <span className="text-xs font-mono">03:34</span>
              </div>
            </div>
          </div>
        );

      case 'video':
        return (
          <div className="p-4 flex flex-col items-center">
            <div className="w-full max-w-xl h-64 bg-slate-950 rounded-xl border border-slate-800 relative flex flex-col items-center justify-center overflow-hidden group shadow-2xl">
              <Film className="w-16 h-16 text-rose-500 mb-2 opacity-80" />
              <p className="text-sm font-bold text-slate-200">{file.name}</p>
              <span className="px-2 py-0.5 text-[10px] bg-rose-500/20 text-rose-300 rounded border border-rose-500/30 mt-1">
                4K Wi-Fi Video Stream
              </span>

              <button className="absolute inset-0 bg-slate-950/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center text-white">
                <div className="w-14 h-14 rounded-full bg-rose-600 flex items-center justify-center shadow-lg hover:scale-110 transition">
                  <Play className="w-7 h-7 fill-white ml-1" />
                </div>
              </button>
            </div>
          </div>
        );

      case 'text':
      case 'code':
        return (
          <div className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono text-cyan-400 flex items-center gap-1">
                <Code className="w-3.5 h-3.5" />
                <span>Text Viewer</span>
              </span>
              {file.textContent && (
                <button
                  onClick={() => copyTextToClipboard(file.textContent || '')}
                  className="flex items-center gap-1 text-xs text-slate-400 hover:text-white px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700"
                >
                  {copiedText ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedText ? 'Copied' : 'Copy'}</span>
                </button>
              )}
            </div>

            <pre className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-slate-200 text-xs font-mono max-h-80 overflow-y-auto whitespace-pre-wrap leading-relaxed shadow-inner">
              {file.textContent || 'No text content available to display.'}
            </pre>
          </div>
        );

      case 'app':
        return (
          <div className="p-6 flex flex-col items-center text-center">
            <div className="w-20 h-20 rounded-2xl bg-teal-500/20 border border-teal-500/40 flex items-center justify-center text-teal-400 mb-3 shadow-lg">
              <Smartphone className="w-10 h-10" />
            </div>
            <h3 className="text-base font-bold text-slate-100">{file.name}</h3>
            <span className="mt-1 px-2.5 py-0.5 text-xs font-semibold rounded-full bg-teal-500/10 text-teal-400 border border-teal-500/30">
              Android Application Package (.APK)
            </span>

            <div className="grid grid-cols-2 gap-3 w-full max-w-sm mt-5 text-left text-xs bg-slate-950 p-4 rounded-xl border border-slate-800">
              <div>
                <span className="text-slate-500">Package:</span>
                <p className="font-mono text-slate-300 truncate">com.wifi.explorer.pro</p>
              </div>
              <div>
                <span className="text-slate-500">Version:</span>
                <p className="font-mono text-slate-300">v4.2.0 (Build 84)</p>
              </div>
              <div>
                <span className="text-slate-500">Min SDK:</span>
                <p className="font-mono text-slate-300">Android 8.0 (API 26)</p>
              </div>
              <div>
                <span className="text-slate-500">Architecture:</span>
                <p className="font-mono text-slate-300">arm64-v8a</p>
              </div>
            </div>
          </div>
        );

      default:
        return (
          <div className="p-8 flex flex-col items-center justify-center text-center">
            <FileText className="w-16 h-16 text-slate-500 mb-3" />
            <h3 className="text-base font-bold text-slate-200">{file.name}</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-xs">
              Direct preview is not supported for this file type. Click Download below to save it to your local device.
            </p>
          </div>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-slate-900 border border-slate-800 text-white rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-slate-800 text-cyan-400">
              {file.type === 'image' && <ImageIcon className="w-5 h-5" />}
              {file.type === 'audio' && <Music className="w-5 h-5" />}
              {file.type === 'video' && <Film className="w-5 h-5" />}
              {(file.type === 'document' || file.type === 'text') && <FileText className="w-5 h-5" />}
              {file.type === 'app' && <Smartphone className="w-5 h-5" />}
              {file.type === 'code' && <Code className="w-5 h-5" />}
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-100 truncate max-w-xs sm:max-w-md">
                {file.name}
              </h2>
              <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-0.5">
                <span className="flex items-center gap-1">
                  <HardDrive className="w-3 h-3 text-cyan-400" />
                  {formatBytes(file.size)}
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-cyan-400" />
                  {formatDate(file.modified)}
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto">
          {renderContent()}
        </div>

        {/* Footer Actions */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
          <span className="text-xs text-slate-400">
            Path: <span className="font-mono text-slate-300">{file.path}/{file.name}</span>
          </span>

          <button
            onClick={() => onDownload(file)}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-600/20 transition"
          >
            <Download className="w-4 h-4" />
            <span>Download File</span>
          </button>
        </div>

      </div>
    </div>
  );
};
