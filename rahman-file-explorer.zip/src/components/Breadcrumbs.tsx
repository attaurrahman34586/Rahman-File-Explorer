import React, { useState } from 'react';
import { 
  ChevronRight, 
  Home, 
  FolderPlus, 
  Upload, 
  Trash2, 
  Download, 
  LayoutGrid, 
  List, 
  ArrowUpDown,
  CheckSquare,
  Square
} from 'lucide-react';
import { ViewMode, SortField, SortOrder } from '../types';

interface BreadcrumbsProps {
  currentPath: string;
  onNavigatePath: (path: string) => void;
  onOpenCreateFolder: () => void;
  onOpenUpload: () => void;
  selectedCount: number;
  totalCount: number;
  isAllSelected: boolean;
  onToggleSelectAll: () => void;
  onBatchDelete: () => void;
  onBatchDownload: () => void;
  viewMode: ViewMode;
  onChangeViewMode: (mode: ViewMode) => void;
  sortField: SortField;
  sortOrder: SortOrder;
  onChangeSort: (field: SortField) => void;
  isReadOnly: boolean;
}

export const Breadcrumbs: React.FC<BreadcrumbsProps> = ({
  currentPath,
  onNavigatePath,
  onOpenCreateFolder,
  onOpenUpload,
  selectedCount,
  totalCount,
  isAllSelected,
  onToggleSelectAll,
  onBatchDelete,
  onBatchDownload,
  viewMode,
  onChangeViewMode,
  sortField,
  sortOrder,
  onChangeSort,
  isReadOnly,
}) => {
  const [showSortDropdown, setShowSortDropdown] = useState(false);

  // Split path into segments e.g. "/Pictures/Vacation" -> ["Pictures", "Vacation"]
  const pathSegments = currentPath
    .split('/')
    .filter(Boolean);

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-3 shadow-sm flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
      
      {/* Path Breadcrumbs */}
      <div className="flex items-center gap-1 overflow-x-auto py-1 scrollbar-none text-sm font-medium">
        <button
          onClick={() => onNavigatePath('/')}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition shrink-0 ${
            currentPath === '/'
              ? 'bg-cyan-50 text-cyan-700 font-bold dark:bg-cyan-950/50 dark:text-cyan-300'
              : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Home className="w-4 h-4 text-cyan-500" />
          <span>Internal Storage</span>
        </button>

        {pathSegments.map((segment, idx) => {
          const targetPath = '/' + pathSegments.slice(0, idx + 1).join('/');
          const isLast = idx === pathSegments.length - 1;

          return (
            <React.Fragment key={targetPath}>
              <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
              <button
                onClick={() => onNavigatePath(targetPath)}
                className={`px-2 py-1 rounded-lg transition shrink-0 ${
                  isLast
                    ? 'bg-cyan-50 text-cyan-700 font-bold dark:bg-cyan-950/50 dark:text-cyan-300'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {segment}
              </button>
            </React.Fragment>
          );
        })}
      </div>

      {/* Action Buttons & Batch Toolbar */}
      <div className="flex items-center justify-between md:justify-end gap-2 shrink-0">
        
        {/* Bulk Selection Bar if items selected */}
        {selectedCount > 0 ? (
          <div className="flex items-center gap-2 bg-slate-900 text-white dark:bg-cyan-950/80 dark:text-cyan-100 px-3 py-1.5 rounded-xl text-xs shadow-md border border-slate-700 dark:border-cyan-800 animate-in fade-in">
            <button
              onClick={onToggleSelectAll}
              className="flex items-center gap-1 hover:text-cyan-300 transition"
              title="Toggle Select All"
            >
              {isAllSelected ? (
                <CheckSquare className="w-4 h-4 text-cyan-400" />
              ) : (
                <Square className="w-4 h-4 text-slate-400" />
              )}
              <span className="font-bold">{selectedCount} selected</span>
            </button>

            <div className="h-4 w-px bg-slate-700 dark:bg-cyan-800 mx-1" />

            <button
              onClick={onBatchDownload}
              className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 transition font-medium"
              title="Download Selected"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download</span>
            </button>

            {!isReadOnly && (
              <button
                onClick={onBatchDelete}
                className="flex items-center gap-1 text-rose-400 hover:text-rose-300 transition font-medium ml-1"
                title="Delete Selected"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>
            )}
          </div>
        ) : (
          /* Main Create / Upload Actions */
          <div className="flex items-center gap-2">
            {!isReadOnly && (
              <>
                <button
                  onClick={onOpenCreateFolder}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-200 text-xs font-semibold border border-slate-200 dark:border-slate-700 transition"
                >
                  <FolderPlus className="w-4 h-4 text-amber-500" />
                  <span className="hidden sm:inline">New Folder</span>
                </button>

                <button
                  onClick={onOpenUpload}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-md shadow-cyan-600/20 transition"
                >
                  <Upload className="w-4 h-4" />
                  <span>Upload</span>
                </button>
              </>
            )}
          </div>
        )}

        {/* View Switcher & Sort Menu */}
        <div className="flex items-center gap-1 border-l border-slate-200 dark:border-slate-800 pl-2">
          
          {/* View Toggle */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-xl border border-slate-200 dark:border-slate-700">
            <button
              onClick={() => onChangeViewMode('grid')}
              className={`p-1.5 rounded-lg text-xs transition ${
                viewMode === 'grid'
                  ? 'bg-white text-slate-900 shadow dark:bg-slate-700 dark:text-white'
                  : 'text-slate-500 hover:text-slate-800 dark:text-slate-400'
              }`}
              title="Grid View"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => onChangeViewMode('list')}
              className={`p-1.5 rounded-lg text-xs transition ${
                viewMode === 'list'
                  ? 'bg-white text-slate-900 shadow dark:bg-slate-700 dark:text-white'
                  : 'text-slate-500 hover:text-slate-800 dark:text-slate-400'
              }`}
              title="List View"
            >
              <List className="w-4 h-4" />
            </button>
          </div>

          {/* Sort Menu Toggle */}
          <div className="relative">
            <button
              onClick={() => setShowSortDropdown(!showSortDropdown)}
              className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition"
              title="Sort Options"
            >
              <ArrowUpDown className="w-4 h-4 text-cyan-500" />
            </button>

            {showSortDropdown && (
              <div className="absolute right-0 mt-2 w-40 bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-200 dark:border-slate-800 py-1.5 z-20">
                <div className="px-3 py-1 text-[10px] font-extrabold uppercase text-slate-400">
                  Sort By
                </div>
                {(['name', 'size', 'modified', 'type'] as SortField[]).map((field) => (
                  <button
                    key={field}
                    onClick={() => {
                      onChangeSort(field);
                      setShowSortDropdown(false);
                    }}
                    className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between hover:bg-slate-100 dark:hover:bg-slate-800 ${
                      sortField === field
                        ? 'font-bold text-cyan-600 dark:text-cyan-400'
                        : 'text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <span className="capitalize">{field}</span>
                    {sortField === field && (
                      <span className="text-[10px] font-bold">
                        {sortOrder === 'asc' ? '↑' : '↓'}
                      </span>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
