import React, { useState } from 'react';
import { 
  Wifi, 
  Power, 
  QrCode, 
  Lock, 
  Copy, 
  Check, 
  Globe, 
  ShieldCheck, 
  Smartphone, 
  Settings, 
  Laptop, 
  Radio,
  ExternalLink,
  Flame,
  Zap,
  Square,
  X,
  RotateCcw,
  WifiOff
} from 'lucide-react';
import { ServerSettings, StorageInfo } from '../types';

interface MobileSimulatedAppProps {
  settings: ServerSettings;
  storage: StorageInfo;
  onUpdateSettings: (newSettings: Partial<ServerSettings>) => void;
  onOpenQrModal: () => void;
  onOpenWebExplorer: () => void;
}

export const MobileSimulatedApp: React.FC<MobileSimulatedAppProps> = ({
  settings,
  storage,
  onUpdateSettings,
  onOpenQrModal,
  onOpenWebExplorer,
}) => {
  const [copied, setCopied] = useState(false);
  const [showRecentApps, setShowRecentApps] = useState(false);
  const [isAppClearedFromRecents, setIsAppClearedFromRecents] = useState(false);

  const serverUrl = `http://${settings.ipAddress}:${settings.port}`;

  const copyUrl = () => {
    navigator.clipboard.writeText(serverUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleToggleHotspot = async () => {
    const newHotspotState = !settings.hotspotActive;
    try {
      await fetch('/api/hotspot-toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ active: newHotspotState }),
      });
      onUpdateSettings({ hotspotActive: newHotspotState, isServerRunning: newHotspotState });
    } catch {
      onUpdateSettings({ hotspotActive: newHotspotState });
    }
  };

  const handleClearFromRecents = async () => {
    try {
      await fetch('/api/app-close', { method: 'POST' });
    } catch {
      // ignore
    }
    onUpdateSettings({ isServerRunning: false });
    setIsAppClearedFromRecents(true);
    setShowRecentApps(false);
  };

  const handleRelaunchApp = () => {
    setIsAppClearedFromRecents(false);
    onUpdateSettings({ isServerRunning: true, hotspotActive: true });
  };

  return (
    <div className="flex flex-col items-center justify-center py-6 px-4">
      {/* Smartphone Outer Frame */}
      <div className="w-full max-w-sm bg-slate-950 border-4 border-slate-800 rounded-[40px] p-4 shadow-2xl shadow-cyan-950/40 relative overflow-hidden min-h-[640px] flex flex-col justify-between">
        
        {/* Notch / Dynamic Island */}
        <div className="w-28 h-4 bg-slate-900 rounded-full mx-auto mb-2 flex items-center justify-center shrink-0">
          <div className="w-3 h-3 rounded-full bg-slate-950 border border-slate-800" />
        </div>

        {isAppClearedFromRecents ? (
          /* Phone Home Screen after clearing app from recent apps */
          <div className="flex-1 flex flex-col items-center justify-center text-center p-6 space-y-4 animate-in fade-in">
            <div className="w-16 h-16 rounded-3xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-600 shadow-inner">
              <Power className="w-8 h-8 text-rose-500" />
            </div>

            <div>
              <h3 className="text-sm font-bold text-slate-200">App Closed & Server Terminated</h3>
              <p className="text-xs text-slate-400 mt-1">
                WiFi File Explorer Pro was cleared from Recent Apps. Server on port 8888 and hotspot background services stopped.
              </p>
            </div>

            <button
              onClick={handleRelaunchApp}
              className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold shadow-lg shadow-cyan-500/20 transition"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Tap to Open App Again</span>
            </button>
          </div>
        ) : (
          /* Android App Content */
          <div className="flex-1 flex flex-col justify-between">
            <div>
              {/* Android App Header */}
              <div className="flex items-center justify-between mb-3 pb-2.5 border-b border-slate-800/80">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-md">
                    <Wifi className="w-4 h-4" />
                  </div>
                  <div>
                    <h2 className="text-xs font-bold text-white tracking-wide">Rahman File Explorer</h2>
                    <span className="text-[9px] font-black text-amber-400 uppercase tracking-widest">PRO SERVER</span>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  {settings.isServerRunning && settings.hotspotActive ? (
                    <>
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                      <span className="text-[10px] font-mono font-bold text-emerald-400">SERVING</span>
                    </>
                  ) : (
                    <>
                      <span className="w-2 h-2 rounded-full bg-amber-500" />
                      <span className="text-[10px] font-mono font-bold text-amber-400">PAUSED</span>
                    </>
                  )}
                </div>
              </div>

              {/* Auto-Start Status Badge */}
              <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-2 mb-3 flex items-center justify-between text-[11px]">
                <div className="flex items-center gap-1.5 text-slate-300">
                  <Zap className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Auto-Started on App Launch</span>
                </div>
                <span className="text-[9px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded font-mono font-bold">
                  Port {settings.port}
                </span>
              </div>

              {/* Hotspot Toggle Card */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 mb-3 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className={`p-2 rounded-xl ${settings.hotspotActive ? 'bg-orange-500/20 text-orange-400' : 'bg-slate-800 text-slate-500'}`}>
                    <Flame className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-100">Mobile Hotspot</h4>
                    <p className="text-[10px] text-slate-400">
                      {settings.hotspotActive ? `SSID: ${settings.ssid}` : 'Hotspot Disabled'}
                    </p>
                  </div>
                </div>

                <button
                  onClick={handleToggleHotspot}
                  className={`px-3 py-1.5 text-[11px] font-bold rounded-xl transition ${
                    settings.hotspotActive
                      ? 'bg-orange-500 text-slate-950 hover:bg-orange-400 shadow-sm'
                      : 'bg-slate-800 text-slate-300 hover:text-white border border-slate-700'
                  }`}
                >
                  {settings.hotspotActive ? 'HOTSPOT ON' : 'ENABLE'}
                </button>
              </div>

              {/* Main Connection URL Box */}
              {settings.isServerRunning && settings.hotspotActive ? (
                <div className="bg-slate-900 border border-cyan-500/30 p-3.5 rounded-2xl mb-3 shadow-lg text-center space-y-2">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                    Connect PC / Laptop Browser To:
                  </span>

                  <div className="flex items-center justify-center gap-2 bg-slate-950 py-2 px-3 rounded-xl border border-slate-800">
                    <Globe className="w-4 h-4 text-cyan-400 shrink-0" />
                    <code className="text-sm font-mono font-bold text-cyan-300">{serverUrl}</code>
                    <button
                      onClick={copyUrl}
                      className="p-1 hover:text-white text-slate-400 transition ml-1"
                      title="Copy Web URL"
                    >
                      {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>

                  <div className="flex items-center justify-center gap-2 pt-1">
                    <button
                      onClick={onOpenQrModal}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
                    >
                      <QrCode className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Show QR Code</span>
                    </button>

                    <button
                      onClick={onOpenWebExplorer}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-md transition"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Open Explorer</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="bg-amber-500/10 border border-amber-500/30 p-3 rounded-2xl text-center text-xs text-amber-300 mb-3 space-y-2">
                  <div className="flex items-center justify-center gap-1.5 font-bold">
                    <WifiOff className="w-4 h-4 text-amber-400" />
                    <span>Hotspot Disabled</span>
                  </div>
                  <p className="text-[10px] text-amber-200/80">
                    Enable Mobile Hotspot above to start serving files wirelessly on port 8888.
                  </p>
                </div>
              )}

              {/* Connected Devices Overview */}
              <div className="bg-slate-900/90 p-3 rounded-2xl border border-slate-800 text-xs space-y-2">
                <div className="flex items-center justify-between text-slate-300 font-semibold border-b border-slate-800 pb-1.5">
                  <span className="flex items-center gap-1.5 text-cyan-400">
                    <Laptop className="w-3.5 h-3.5" />
                    Connected Devices:
                  </span>
                  <span className="text-[10px] bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded-full font-bold">
                    {settings.activeClients} Active
                  </span>
                </div>

                <div className="space-y-1 text-[11px] text-slate-400 font-mono">
                  <div className="flex justify-between py-0.5">
                    <span>Windows PC (Chrome)</span>
                    <span className="text-emerald-400">192.168.43.12</span>
                  </div>
                  <div className="flex justify-between py-0.5">
                    <span>MacBook Air (Safari)</span>
                    <span className="text-emerald-400">192.168.43.40</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Android System Navigation Bar (Home / Recents) */}
            <div className="pt-3 border-t border-slate-900 flex items-center justify-around text-slate-500">
              <button
                onClick={() => setShowRecentApps(true)}
                className="p-1.5 hover:text-slate-200 transition flex items-center gap-1 text-[11px]"
                title="Recent Apps Switcher"
              >
                <Square className="w-4 h-4 text-slate-400" />
                <span className="font-semibold text-slate-400">Recent Apps</span>
              </button>
            </div>
          </div>
        )}

        {/* Recent Apps Switcher Drawer / Modal Simulator */}
        {showRecentApps && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md z-40 p-4 flex flex-col justify-between animate-in fade-in">
            <div>
              <div className="flex items-center justify-between text-white pb-3 border-b border-slate-800">
                <span className="text-xs font-bold text-slate-300">Android Recent Apps</span>
                <button
                  onClick={() => setShowRecentApps(false)}
                  className="p-1 text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* App Card in Recents */}
              <div className="mt-6 bg-slate-900 border border-slate-700 rounded-2xl p-4 shadow-xl space-y-3 relative group">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg bg-cyan-600 flex items-center justify-center text-white">
                      <Wifi className="w-3.5 h-3.5" />
                    </div>
                    <span className="text-xs font-bold text-white">Rahman File Explorer Pro</span>
                  </div>
                  <button
                    onClick={handleClearFromRecents}
                    className="p-1 text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 rounded-lg transition"
                    title="Close and terminate app"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-[10px] text-slate-400 font-mono">
                  <span>Server Port: 8888</span>
                  <p className="text-emerald-400 mt-0.5">Status: Running in Background</p>
                </div>

                <div className="text-[10px] text-slate-500 italic text-center">
                  Clearing from Recent Apps terminates the server process.
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <button
                onClick={handleClearFromRecents}
                className="w-full py-2.5 bg-rose-600/90 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition shadow-lg"
              >
                Clear All / Close App
              </button>
              <button
                onClick={() => setShowRecentApps(false)}
                className="w-full py-2 bg-slate-900 text-slate-300 rounded-xl text-xs font-semibold hover:bg-slate-800"
              >
                Back to App
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
