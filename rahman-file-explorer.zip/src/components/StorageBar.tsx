import React from 'react';
import { 
  HardDrive, 
  Image as ImageIcon, 
  Film, 
  Music, 
  FileText, 
  Archive, 
  Smartphone, 
  Layers 
} from 'lucide-react';
import { StorageInfo, FileType } from '../types';
import { formatBytes } from '../utils/formatters';

interface StorageBarProps {
  storage: StorageInfo;
  activeCategoryFilter: FileType | 'all';
  onSelectCategory: (cat: FileType | 'all') => void;
}

export const StorageBar: React.FC<StorageBarProps> = ({
  storage,
  activeCategoryFilter,
  onSelectCategory,
}) => {
  const usedPercentage = Math.round((storage.usedBytes / storage.totalBytes) * 100);

  const categoriesConfig: Array<{
    id: FileType | 'all';
    label: string;
    icon: React.ReactNode;
    bytes: number;
    color: string;
    bgColor: string;
  }> = [
    {
      id: 'all',
      label: 'All Files',
      icon: <Layers className="w-3.5 h-3.5" />,
      bytes: storage.usedBytes,
      color: 'bg-slate-700 dark:bg-slate-200',
      bgColor: 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-200',
    },
    {
      id: 'image',
      label: 'Photos',
      icon: <ImageIcon className="w-3.5 h-3.5" />,
      bytes: storage.categories.images,
      color: 'bg-purple-500',
      bgColor: 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/30',
    },
    {
      id: 'video',
      label: 'Videos',
      icon: <Film className="w-3.5 h-3.5" />,
      bytes: storage.categories.videos,
      color: 'bg-rose-500',
      bgColor: 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30',
    },
    {
      id: 'audio',
      label: 'Music',
      icon: <Music className="w-3.5 h-3.5" />,
      bytes: storage.categories.audio,
      color: 'bg-emerald-500',
      bgColor: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30',
    },
    {
      id: 'document',
      label: 'Documents',
      icon: <FileText className="w-3.5 h-3.5" />,
      bytes: storage.categories.documents,
      color: 'bg-blue-500',
      bgColor: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/30',
    },
    {
      id: 'archive',
      label: 'Archives',
      icon: <Archive className="w-3.5 h-3.5" />,
      bytes: storage.categories.archives,
      color: 'bg-orange-500',
      bgColor: 'bg-orange-500/10 text-orange-600 dark:text-orange-400 border-orange-500/30',
    },
    {
      id: 'app',
      label: 'APKs & Apps',
      icon: <Smartphone className="w-3.5 h-3.5" />,
      bytes: storage.categories.apps,
      color: 'bg-teal-500',
      bgColor: 'bg-teal-500/10 text-teal-600 dark:text-teal-400 border-teal-500/30',
    },
  ];

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2">
          <HardDrive className="w-5 h-5 text-cyan-500" />
          <h2 className="text-sm font-semibold text-slate-800 dark:text-slate-100">
            Wi-Fi Device Storage
          </h2>
          <span className="text-xs text-slate-500 dark:text-slate-400">
            ({usedPercentage}% used)
          </span>
        </div>
        <div className="text-xs font-medium text-slate-600 dark:text-slate-300">
          <span className="text-slate-900 dark:text-white font-bold">{formatBytes(storage.usedBytes)}</span>
          {' used of '}
          <span className="text-slate-500">{formatBytes(storage.totalBytes)}</span>
          {' ('}
          <span className="text-emerald-600 dark:text-emerald-400 font-semibold">{formatBytes(storage.freeBytes)} free</span>
          {')'}
        </div>
      </div>

      {/* Storage Visual Segment Bar */}
      <div className="w-full h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden flex shadow-inner mb-4">
        {categoriesConfig.slice(1).map((cat) => {
          const pct = (cat.bytes / storage.totalBytes) * 100;
          if (pct <= 0) return null;
          return (
            <div
              key={cat.id}
              style={{ width: `${pct}%` }}
              className={`${cat.color} transition-all duration-500`}
              title={`${cat.label}: ${formatBytes(cat.bytes)}`}
            />
          );
        })}
      </div>

      {/* Category Quick Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {categoriesConfig.map((cat) => {
          const isSelected = activeCategoryFilter === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition shrink-0 ${
                isSelected
                  ? 'bg-slate-900 text-white border-slate-900 dark:bg-cyan-500 dark:text-slate-950 dark:border-cyan-400 shadow-sm'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100 dark:bg-slate-800/80 dark:text-slate-300 dark:border-slate-700 hover:dark:bg-slate-800'
              }`}
            >
              {cat.icon}
              <span>{cat.label}</span>
              {cat.id !== 'all' && (
                <span className="opacity-70 text-[10px]">
                  ({formatBytes(cat.bytes)})
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
