import React, { useState } from 'react';
import { 
  Folder, 
  File, 
  Image as ImageIcon, 
  Film, 
  Music, 
  FileText, 
  Archive, 
  Smartphone, 
  Code, 
  Download, 
  Trash2, 
  Edit3, 
  Eye, 
  MoreVertical, 
  CheckCircle2, 
  Circle,
  FileDown
} from 'lucide-react';
import { FileItem, FileType, ViewMode } from '../types';
import { formatBytes, formatDate, getFileTypeBadgeColor } from '../utils/formatters';

interface FileListProps {
  files: FileItem[];
  selectedIds: string[];
  onToggleSelect: (id: string) => void;
  onOpenFolder: (folderPath: string) => void;
  onPreviewFile: (file: FileItem) => void;
  onDownloadFile: (file: FileItem) => void;
  onRenameFile: (file: FileItem) => void;
  onDeleteFile: (file: FileItem) => void;
  viewMode: ViewMode;
  isReadOnly: boolean;
  onDropFiles: (files: FileList) => void;
}

export const FileList: React.FC<FileListProps> = ({
  files,
  selectedIds,
  onToggleSelect,
  onOpenFolder,
  onPreviewFile,
  onDownloadFile,
  onRenameFile,
  onDeleteFile,
  viewMode,
  isReadOnly,
  onDropFiles,
}) => {
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const renderFileIcon = (type: FileType, name: string) => {
    switch (type) {
      case 'folder':
        return <Folder className="w-8 h-8 text-amber-500 fill-amber-500/20" />;
      case 'image':
        return <ImageIcon className="w-8 h-8 text-purple-500" />;
      case 'video':
        return <Film className="w-8 h-8 text-rose-500" />;
      case 'audio':
        return <Music className="w-8 h-8 text-emerald-500" />;
      case 'document':
      case 'text':
        return <FileText className="w-8 h-8 text-blue-500" />;
      case 'archive':
        return <Archive className="w-8 h-8 text-orange-500" />;
      case 'app':
        return <Smartphone className="w-8 h-8 text-teal-500" />;
      case 'code':
        return <Code className="w-8 h-8 text-indigo-500" />;
      default:
        return <File className="w-8 h-8 text-slate-400" />;
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onDropFiles(e.dataTransfer.files);
    }
  };

  if (files.length === 0) {
    return (
      <div 
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`flex flex-col items-center justify-center p-12 border-2 border-dashed rounded-2xl text-center transition ${
          isDragOver 
            ? 'border-cyan-500 bg-cyan-500/10 text-cyan-500' 
            : 'border-slate-300 dark:border-slate-800 bg-white dark:bg-slate-900/50 text-slate-500 dark:text-slate-400'
        }`}
      >
        <div className="w-16 h-16 rounded-full bg-cyan-500/10 flex items-center justify-center text-cyan-500 mb-3">
          <FileDown className="w-8 h-8 animate-bounce" />
        </div>
        <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">This folder is empty</h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mt-1">
          Drag and drop files anywhere in this window to upload over Wi-Fi, or use the Upload button above.
        </p>
      </div>
    );
  }

  return (
    <div
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`relative rounded-2xl transition ${
        isDragOver ? 'ring-2 ring-cyan-500 ring-offset-2 ring-offset-slate-900 bg-cyan-500/5' : ''
      }`}
    >
      {/* Drag Over Overlay Alert */}
      {isDragOver && (
        <div className="absolute inset-0 z-30 bg-cyan-950/90 backdrop-blur-sm rounded-2xl border-2 border-cyan-400 border-dashed flex flex-col items-center justify-center text-cyan-300 pointer-events-none">
          <FileDown className="w-12 h-12 mb-2 animate-bounce text-cyan-400" />
          <p className="text-lg font-bold">Drop files here to Upload over Wi-Fi</p>
        </div>
      )}

      {viewMode === 'grid' ? (
        /* GRID VIEW */
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
          {files.map((file) => {
            const isSelected = selectedIds.includes(file.id);
            const isFolder = file.type === 'folder';

            return (
              <div
                key={file.id}
                className={`group relative bg-white dark:bg-slate-900 border rounded-2xl p-3 flex flex-col justify-between transition hover:shadow-md ${
                  isSelected
                    ? 'border-cyan-500 bg-cyan-500/5 dark:bg-cyan-950/30 ring-1 ring-cyan-500'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                {/* Select Checkbox */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleSelect(file.id);
                  }}
                  className="absolute top-2 left-2 z-10 p-1 rounded-lg text-slate-400 hover:text-cyan-500 transition opacity-80 group-hover:opacity-100"
                >
                  {isSelected ? (
                    <CheckCircle2 className="w-5 h-5 text-cyan-500 fill-cyan-500/20" />
                  ) : (
                    <Circle className="w-5 h-5 text-slate-300 dark:text-slate-600" />
                  )}
                </button>

                {/* Context Menu Button */}
                <div className="absolute top-2 right-2 z-10">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveMenuId(activeMenuId === file.id ? null : file.id);
                    }}
                    className="p-1 rounded-lg text-slate-400 hover:text-slate-800 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                  >
                    <MoreVertical className="w-4 h-4" />
                  </button>

                  {/* Dropdown Options */}
                  {activeMenuId === file.id && (
                    <div 
                      onMouseLeave={() => setActiveMenuId(null)}
                      className="absolute right-0 mt-1 w-36 bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-200 dark:border-slate-800 py-1 z-30 animate-in fade-in"
                    >
                      {!isFolder && (
                        <button
                          onClick={() => {
                            onPreviewFile(file);
                            setActiveMenuId(null);
                          }}
                          className="w-full text-left px-3 py-1.5 text-xs flex items-center gap-2 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300"
                        >
                          <Eye className="w-3.5 h-3.5 text-cyan-500" />
                          <span>Preview</span>
                        </button>
                      )}

                      <button
                        onClick={() => {
                          onDownloadFile(file);
                          setActiveMenuId(null);
                        }}
                        className="w-full text-left px-3 py-1.5 text-xs flex items-center gap-2 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300"
                      >
                        <Download className="w-3.5 h-3.5 text-emerald-500" />
                        <span>Download</span>
                      </button>

                      {!isReadOnly && (
                        <>
                          <button
                            onClick={() => {
                              onRenameFile(file);
                              setActiveMenuId(null);
                            }}
                            className="w-full text-left px-3 py-1.5 text-xs flex items-center gap-2 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300"
                          >
                            <Edit3 className="w-3.5 h-3.5 text-amber-500" />
                            <span>Rename</span>
                          </button>

                          <button
                            onClick={() => {
                              onDeleteFile(file);
                              setActiveMenuId(null);
                            }}
                            className="w-full text-left px-3 py-1.5 text-xs flex items-center gap-2 hover:bg-slate-100 dark:hover:bg-slate-800 text-rose-600 dark:text-rose-400"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Delete</span>
                          </button>
                        </>
                      )}
                    </div>
                  )}
                </div>

                {/* File / Folder Main Clickable Card Body */}
                <div
                  onClick={() => {
                    if (isFolder) {
                      const newPath = file.path === '/' ? `/${file.name}` : `${file.path}/${file.name}`;
                      onOpenFolder(newPath);
                    } else {
                      onPreviewFile(file);
                    }
                  }}
                  className="cursor-pointer flex flex-col items-center pt-5 pb-2 text-center"
                >
                  <div className="mb-2 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 group-hover:scale-105 transition">
                    {renderFileIcon(file.type, file.name)}
                  </div>

                  <h4 className="text-xs font-semibold text-slate-800 dark:text-slate-100 truncate w-full px-1" title={file.name}>
                    {file.name}
                  </h4>

                  <div className="mt-1 flex items-center gap-1.5 text-[10px] text-slate-500 dark:text-slate-400">
                    <span>{isFolder ? 'Folder' : formatBytes(file.size)}</span>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      ) : (
        /* LIST VIEW */
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 text-[11px] font-extrabold uppercase text-slate-500 dark:text-slate-400">
                  <th className="py-2.5 px-3 w-10 text-center"></th>
                  <th className="py-2.5 px-3">Name</th>
                  <th className="py-2.5 px-3">Type</th>
                  <th className="py-2.5 px-3">Size</th>
                  <th className="py-2.5 px-3 hidden md:table-cell">Modified</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 text-xs">
                {files.map((file) => {
                  const isSelected = selectedIds.includes(file.id);
                  const isFolder = file.type === 'folder';

                  return (
                    <tr
                      key={file.id}
                      className={`hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition ${
                        isSelected ? 'bg-cyan-500/10 dark:bg-cyan-950/40' : ''
                      }`}
                    >
                      {/* Checkbox */}
                      <td className="py-2 px-3 text-center">
                        <button
                          onClick={() => onToggleSelect(file.id)}
                          className="text-slate-400 hover:text-cyan-500"
                        >
                          {isSelected ? (
                            <CheckCircle2 className="w-4 h-4 text-cyan-500" />
                          ) : (
                            <Circle className="w-4 h-4 text-slate-300 dark:text-slate-600" />
                          )}
                        </button>
                      </td>

                      {/* Name & Icon */}
                      <td className="py-2 px-3">
                        <div
                          onClick={() => {
                            if (isFolder) {
                              const newPath = file.path === '/' ? `/${file.name}` : `${file.path}/${file.name}`;
                              onOpenFolder(newPath);
                            } else {
                              onPreviewFile(file);
                            }
                          }}
                          className="flex items-center gap-2.5 cursor-pointer font-medium text-slate-800 dark:text-slate-200 hover:text-cyan-600 dark:hover:text-cyan-400"
                        >
                          <div className="shrink-0">
                            {renderFileIcon(file.type, file.name)}
                          </div>
                          <span className="truncate max-w-xs sm:max-w-md">{file.name}</span>
                        </div>
                      </td>

                      {/* Type Badge */}
                      <td className="py-2 px-3">
                        <span className={`px-2 py-0.5 text-[10px] font-bold uppercase rounded-md border ${getFileTypeBadgeColor(file.type)}`}>
                          {file.type}
                        </span>
                      </td>

                      {/* Size */}
                      <td className="py-2 px-3 font-mono text-slate-600 dark:text-slate-400">
                        {isFolder ? '—' : formatBytes(file.size)}
                      </td>

                      {/* Modified Date */}
                      <td className="py-2 px-3 hidden md:table-cell text-slate-500 dark:text-slate-400">
                        {formatDate(file.modified)}
                      </td>

                      {/* Actions */}
                      <td className="py-2 px-3 text-right">
                        <div className="flex items-center justify-end gap-1">
                          {!isFolder && (
                            <button
                              onClick={() => onPreviewFile(file)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                              title="Preview File"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                          )}
                          <button
                            onClick={() => onDownloadFile(file)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                            title="Download File"
                          >
                            <Download className="w-4 h-4" />
                          </button>
                          {!isReadOnly && (
                            <>
                              <button
                                onClick={() => onRenameFile(file)}
                                className="p-1.5 rounded-lg text-slate-400 hover:text-amber-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                                title="Rename"
                              >
                                <Edit3 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => onDeleteFile(file)}
                                className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                                title="Delete"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
