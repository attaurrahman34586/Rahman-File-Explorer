import React, { useState } from 'react';
import { 
  Wifi, 
  QrCode, 
  Settings, 
  Smartphone, 
  Activity, 
  Search, 
  Copy, 
  Check, 
  Lock, 
  ShieldCheck, 
  Globe,
  Radio,
  Download
} from 'lucide-react';
import { ServerSettings } from '../types';

interface HeaderProps {
  settings: ServerSettings;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onOpenQrModal: () => void;
  onOpenSettingsModal: () => void;
  onOpenTransferModal: () => void;
  isMobileSimMode: boolean;
  onToggleMobileSimMode: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  searchQuery,
  onSearchChange,
  onOpenQrModal,
  onOpenSettingsModal,
  onOpenTransferModal,
  isMobileSimMode,
  onToggleMobileSimMode,
}) => {
  const [copied, setCopied] = useState(false);
  const serverUrl = `http://${settings.ipAddress}:${settings.port}`;

  const copyUrlToClipboard = () => {
    navigator.clipboard.writeText(serverUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <header className="sticky top-0 z-30 bg-slate-900 text-white border-b border-slate-800 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col md:flex-row items-center justify-between gap-3">
          
          {/* Logo & Title */}
          <div className="flex items-center justify-between w-full md:w-auto">
            <div className="flex items-center gap-3">
              <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 shadow-md shadow-cyan-500/20">
                <Wifi className="w-6 h-6 text-white animate-pulse" />
                <span className="absolute -bottom-1 -right-1 flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                </span>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-lg font-bold tracking-wide text-slate-100">Rahman File Explorer</h1>
                  <span className="px-1.5 py-0.5 text-[10px] font-extrabold uppercase tracking-wider rounded bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-sm">
                    PRO
                  </span>
                </div>
                <p className="text-xs text-slate-400 flex items-center gap-1.5">
                  <Radio className="w-3 h-3 text-emerald-400" />
                  <span>Wi-Fi Network: <strong className="text-slate-200">{settings.ssid}</strong></span>
                </p>
              </div>
            </div>

            {/* Mobile View Toggle Switch on small screens */}
            <button
              onClick={onToggleMobileSimMode}
              className="md:hidden flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700 transition"
              title="Toggle Mobile Phone Server Mode"
            >
              <Smartphone className="w-4 h-4 text-cyan-400" />
              <span>{isMobileSimMode ? 'Web App' : 'Phone Mode'}</span>
            </button>
          </div>

          {/* Wi-Fi URL Bar & Quick Actions */}
          <div className="flex flex-wrap items-center justify-center md:justify-end gap-2 w-full md:w-auto">
            
            {/* IP Connection Pill */}
            <div className="flex items-center bg-slate-950/80 border border-slate-800 rounded-xl p-1 shadow-inner">
              <div className="px-3 py-1 flex items-center gap-2 text-xs font-mono text-cyan-300">
                <Globe className="w-3.5 h-3.5 text-cyan-400" />
                <span>{serverUrl}</span>
              </div>
              <button
                onClick={copyUrlToClipboard}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition relative"
                title="Copy Web URL"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            {/* QR Code Launcher */}
            <button
              onClick={onOpenQrModal}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/80 transition shadow-sm"
              title="Show Wi-Fi QR Code for mobile connection"
            >
              <QrCode className="w-4 h-4 text-cyan-400" />
              <span className="hidden sm:inline">QR Scan</span>
            </button>

            {/* Live Transfer Monitor */}
            <button
              onClick={onOpenTransferModal}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/80 transition shadow-sm"
              title="Active Transfers & Speed Monitor"
            >
              <Activity className="w-4 h-4 text-emerald-400" />
              <span className="hidden sm:inline">Transfers</span>
            </button>

            {/* Download Source Code ZIP */}
            <a
              href="/rahman-file-explorer.zip"
              download="rahman-file-explorer.zip"
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-md transition"
              title="Download Source Code ZIP"
            >
              <Download className="w-4 h-4" />
              <span>Download ZIP</span>
            </a>

            {/* Security Status Indicator */}
            {settings.pinProtected ? (
              <span 
                className="flex items-center gap-1 px-2.5 py-1.5 text-[11px] font-semibold rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30"
                title="PIN Security Active"
              >
                <Lock className="w-3.5 h-3.5" />
                <span className="hidden lg:inline">PIN Protected</span>
              </span>
            ) : (
              <span 
                className="flex items-center gap-1 px-2.5 py-1.5 text-[11px] font-semibold rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                title="Wi-Fi Security Open"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span className="hidden lg:inline">Secured Wi-Fi</span>
              </span>
            )}

            {/* Mobile App View Toggle (Desktop) */}
            <button
              onClick={onToggleMobileSimMode}
              className={`hidden md:flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-xl border transition shadow-sm ${
                isMobileSimMode 
                  ? 'bg-cyan-600 text-white border-cyan-500 shadow-cyan-600/20' 
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
              }`}
            >
              <Smartphone className="w-4 h-4" />
              <span>{isMobileSimMode ? 'Exit Phone Mode' : 'Phone View'}</span>
            </button>

            {/* Settings Trigger */}
            <button
              onClick={onOpenSettingsModal}
              className="p-2 text-slate-300 hover:text-white rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 transition"
              title="Server Settings & Options"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>

        </div>

        {/* Global Search Bar */}
        <div className="mt-3 relative">
          <Search className="w-4 h-4 absolute left-3.5 top-2.5 text-slate-400 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search files and folders across Wi-Fi storage... (e.g. photos, mp3, pdf, apk)"
            className="w-full pl-10 pr-4 py-2 text-sm bg-slate-950/90 text-slate-100 placeholder-slate-500 rounded-xl border border-slate-800 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/50 transition"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-200"
            >
              Clear
            </button>
          )}
        </div>

      </div>
    </header>
  );
};
