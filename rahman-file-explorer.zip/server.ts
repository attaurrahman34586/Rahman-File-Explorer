import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { execSync } from 'child_process';
import { createServer as createViteServer } from 'vite';
import multer from 'multer';

const app = express();
const PORT = 3000;

function generateSourceZip() {
  const targetZip = path.join(process.cwd(), 'public', 'rahman-file-explorer.zip');
  const tmpZip = '/tmp/rahman-file-explorer-clean.zip';

  try {
    const pyScript = `
import os, zipfile, shutil

tmp_zip = '${tmpZip}'
target_zip = '${targetZip}'

if os.path.exists(tmp_zip):
    os.remove(tmp_zip)

exclude_dirs = {'node_modules', 'dist', '.git', '.cache', '__pycache__', 'wifi_explorer_data'}

with zipfile.ZipFile(tmp_zip, 'w', zipfile.ZIP_DEFLATED) as ziph:
    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        for file in files:
            if file == 'rahman-file-explorer.zip':
                continue
            filepath = os.path.join(root, file)
            arcname = os.path.relpath(filepath, '.')
            if arcname.startswith('tmp') or 'rahman-file-explorer.zip' in arcname:
                continue
            ziph.write(filepath, arcname)

os.makedirs('public', exist_ok=True)
if os.path.exists(target_zip):
    os.remove(target_zip)
shutil.copy2(tmp_zip, target_zip)

with zipfile.ZipFile(target_zip, 'r') as z:
    bad_file = z.testzip()
    if bad_file:
        raise Exception(f'Corrupted file in target zip: {bad_file}')
`;
    execSync(`python3 -c "${pyScript.replace(/"/g, '\\"')}"`, { cwd: process.cwd() });
  } catch (err) {
    console.error('Error generating ZIP archive:', err);
  }
}

// Generate ZIP on server startup
generateSourceZip();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Dynamic ZIP routes to ensure 100% fresh & non-corrupt archive download
app.get('/rahman-file-explorer.zip', (req: Request, res: Response) => {
  const zipPath = path.join(process.cwd(), 'public', 'rahman-file-explorer.zip');
  generateSourceZip();
  if (fs.existsSync(zipPath)) {
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="rahman-file-explorer.zip"');
    res.sendFile(zipPath);
  } else {
    res.status(500).json({ error: 'Failed to generate source ZIP archive' });
  }
});

app.get('/api/download-zip', (req: Request, res: Response) => {
  const zipPath = path.join(process.cwd(), 'public', 'rahman-file-explorer.zip');
  generateSourceZip();
  if (fs.existsSync(zipPath)) {
    res.download(zipPath, 'rahman-file-explorer.zip');
  } else {
    res.status(500).json({ error: 'Failed to generate source ZIP archive' });
  }
});

app.use(express.static(path.join(process.cwd(), 'public')));

// Storage directory setup
const STORAGE_ROOT = path.join(process.cwd(), 'wifi_explorer_data');
if (!fs.existsSync(STORAGE_ROOT)) {
  fs.mkdirSync(STORAGE_ROOT, { recursive: true });
}

// Multer storage config for uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const relativePath = (req.query.path as string) || '/';
    const targetDir = path.join(STORAGE_ROOT, relativePath);
    if (!fs.existsSync(targetDir)) {
      fs.mkdirSync(targetDir, { recursive: true });
    }
    cb(null, targetDir);
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  }
});
const upload = multer({ storage });

// Server State
let lastHeartbeatTime = Date.now();
let appAlive = true;

let serverSettings = {
  ssid: 'AndroidAP_Hotspot',
  ipAddress: '192.168.43.1',
  hotspotIp: '192.168.43.1',
  wifiIp: '192.168.1.105',
  port: 8888,
  isServerRunning: true,
  autoStartOnLaunch: true,
  hotspotActive: true,
  connectionType: 'hotspot' as 'hotspot' | 'wifi' | 'auto',
  pinProtected: false,
  pinCode: '1234',
  readOnly: false,
  activeClients: 3,
  maxUploadSizeMb: 500,
};

let transferHistory: Array<{
  id: string;
  filename: string;
  size: number;
  bytesTransferred: number;
  speedKbps: number;
  type: 'upload' | 'download';
  status: 'completed' | 'in_progress' | 'failed';
  clientIp: string;
  startTime: string;
}> = [
  {
    id: 'tr-1',
    filename: 'Sunset_Goa_4K.jpg',
    size: 4850000,
    bytesTransferred: 4850000,
    speedKbps: 8400,
    type: 'upload',
    status: 'completed',
    clientIp: '192.168.1.112',
    startTime: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
  },
  {
    id: 'tr-2',
    filename: 'Project_Presentation.pdf',
    size: 14200000,
    bytesTransferred: 14200000,
    speedKbps: 12500,
    type: 'download',
    status: 'completed',
    clientIp: '192.168.1.140',
    startTime: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
  },
];

// Helper to initialize realistic demo files
function seedDemoFiles() {
  const folders = [
    'Pictures',
    'Pictures/Vacation 2026',
    'Music',
    'Videos',
    'Documents',
    'Downloads',
    'APKs & Apps',
    'Archives'
  ];

  folders.forEach(folder => {
    const dir = path.join(STORAGE_ROOT, folder);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  });

  // Sample seed files metadata and sample text content if missing
  const sampleFiles = [
    {
      dir: 'Pictures',
      name: 'Wallpaper_Nature.jpg',
      content: 'Demo Image Content',
      type: 'image',
    },
    {
      dir: 'Pictures/Vacation 2026',
      name: 'Beach_Sunset.jpg',
      content: 'Demo Beach Photo',
      type: 'image',
    },
    {
      dir: 'Pictures/Vacation 2026',
      name: 'Mountain_Trek.png',
      content: 'Demo Mountain Photo',
      type: 'image',
    },
    {
      dir: 'Music',
      name: 'Acoustic_Guitar_Vibes.mp3',
      content: 'Demo MP3 Audio Stream Data',
      type: 'audio',
    },
    {
      dir: 'Music',
      name: 'LoFi_Study_Beat.flac',
      content: 'Demo LoFi Audio Stream Data',
      type: 'audio',
    },
    {
      dir: 'Videos',
      name: 'Drone_4K_Nature_Tour.mp4',
      content: 'Demo Video File Stream',
      type: 'video',
    },
    {
      dir: 'Documents',
      name: 'WiFi_Explorer_Guide.pdf',
      content: 'WiFi File Explorer Pro - User Guide & Setup Manual.\nConnect wirelessly over local Wi-Fi network without cables.',
      type: 'document',
    },
    {
      dir: 'Documents',
      name: 'Meeting_Notes_July.txt',
      content: '# Team Sync - July 2026\n- Wi-Fi Transfer Speed tested at 45 MB/s\n- QR code quick scanner added\n- Multi-file drag and drop enabled.',
      type: 'text',
    },
    {
      dir: 'Downloads',
      name: 'Setup_Package_v2.4.zip',
      content: 'Demo Zip Archive File',
      type: 'archive',
    },
    {
      dir: 'APKs & Apps',
      name: 'WiFiFileExplorerPro_v4.2.apk',
      content: 'Demo Android Package File',
      type: 'app',
    },
  ];

  sampleFiles.forEach(file => {
    const filePath = path.join(STORAGE_ROOT, file.dir, file.name);
    if (!fs.existsSync(filePath)) {
      fs.writeFileSync(filePath, file.content, 'utf-8');
    }
  });
}

seedDemoFiles();

// Helper to determine file type category
function getFileType(filename: string, isDirectory: boolean): string {
  if (isDirectory) return 'folder';
  const ext = path.extname(filename).toLowerCase();
  if (['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.bmp'].includes(ext)) return 'image';
  if (['.mp4', '.mkv', '.avi', '.webm', '.mov', '.3gp'].includes(ext)) return 'video';
  if (['.mp3', '.wav', '.ogg', '.flac', '.m4a', '.aac'].includes(ext)) return 'audio';
  if (['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.txt'].includes(ext)) {
    return ext === '.txt' ? 'text' : 'document';
  }
  if (['.zip', '.rar', '.7z', '.tar', '.gz'].includes(ext)) return 'archive';
  if (['.apk', '.xapk'].includes(ext)) return 'app';
  if (['.json', '.js', '.ts', '.html', '.css', '.md', '.py', '.java'].includes(ext)) return 'code';
  return 'document';
}

// API Routes
app.post('/api/heartbeat', (req: Request, res: Response) => {
  lastHeartbeatTime = Date.now();
  appAlive = true;
  // If app is opened, ensure server is auto-running
  serverSettings.isServerRunning = true;
  res.json({ success: true, isServerRunning: serverSettings.isServerRunning, hotspotActive: serverSettings.hotspotActive });
});

// App closed / cleared from recent apps endpoint
app.post('/api/app-close', (req: Request, res: Response) => {
  appAlive = false;
  serverSettings.isServerRunning = false;
  console.log('App closed or cleared from Recent Apps - WiFi File Explorer Server Stopped.');
  res.json({ success: true, message: 'Server and app stopped.' });
});

// Hotspot toggle endpoint
app.post('/api/hotspot-toggle', (req: Request, res: Response) => {
  const { active, ssid } = req.body;
  if (active !== undefined) serverSettings.hotspotActive = Boolean(active);
  if (ssid) serverSettings.ssid = ssid;

  if (serverSettings.hotspotActive) {
    serverSettings.ipAddress = serverSettings.hotspotIp;
  } else {
    serverSettings.ipAddress = serverSettings.wifiIp;
  }

  res.json({ success: true, settings: serverSettings });
});

app.get('/api/status', (req: Request, res: Response) => {
  res.json({
    success: true,
    settings: serverSettings,
    storage: {
      totalBytes: 64 * 1024 * 1024 * 1024, // 64 GB
      usedBytes: 28.4 * 1024 * 1024 * 1024, // 28.4 GB
      freeBytes: 35.6 * 1024 * 1024 * 1024, // 35.6 GB
      categories: {
        images: 12.2 * 1024 * 1024 * 1024,
        videos: 9.8 * 1024 * 1024 * 1024,
        audio: 3.4 * 1024 * 1024 * 1024,
        documents: 1.2 * 1024 * 1024 * 1024,
        archives: 1.1 * 1024 * 1024 * 1024,
        apps: 0.7 * 1024 * 1024 * 1024,
        others: 0.0 * 1024 * 1024 * 1024,
      }
    }
  });
});

// Update server settings
app.post('/api/settings', (req: Request, res: Response) => {
  const { ssid, pinProtected, pinCode, readOnly, isServerRunning, hotspotActive, port, connectionType } = req.body;
  if (ssid !== undefined) serverSettings.ssid = ssid;
  if (pinProtected !== undefined) serverSettings.pinProtected = Boolean(pinProtected);
  if (pinCode !== undefined) serverSettings.pinCode = String(pinCode);
  if (readOnly !== undefined) serverSettings.readOnly = Boolean(readOnly);
  if (isServerRunning !== undefined) serverSettings.isServerRunning = Boolean(isServerRunning);
  if (hotspotActive !== undefined) serverSettings.hotspotActive = Boolean(hotspotActive);
  if (port !== undefined) serverSettings.port = Number(port);
  if (connectionType !== undefined) serverSettings.connectionType = connectionType;

  res.json({ success: true, settings: serverSettings });
});

// Middleware helper to check if server is running and hotspot is enabled
function checkHotspotAndServer(req: Request, res: Response, next: any) {
  if (!serverSettings.isServerRunning) {
    return res.status(503).json({ error: 'Server is currently stopped. Reopen app to start server.' });
  }
  if (!serverSettings.hotspotActive) {
    return res.status(503).json({ error: 'Hotspot is OFF. Hotspot must be enabled to serve files wirelessly.' });
  }
  next();
}

// GET /api/files?path=/
app.get('/api/files', checkHotspotAndServer, (req: Request, res: Response) => {
  try {
    const relPath = (req.query.path as string) || '/';
    const cleanRelPath = relPath.startsWith('/') ? relPath : '/' + relPath;
    const targetDir = path.normalize(path.join(STORAGE_ROOT, cleanRelPath));

    // Security check against directory traversal
    if (!targetDir.startsWith(STORAGE_ROOT)) {
      return res.status(403).json({ error: 'Access denied: Path outside root' });
    }

    if (!fs.existsSync(targetDir)) {
      return res.status(404).json({ error: 'Directory not found' });
    }

    const items = fs.readdirSync(targetDir);
    const result = items.map((name) => {
      const fullPath = path.join(targetDir, name);
      const stat = fs.statSync(fullPath);
      const isDir = stat.isDirectory();
      const fileType = getFileType(name, isDir);
      const itemRelPath = cleanRelPath === '/' ? `/${name}` : `${cleanRelPath}/${name}`;

      let textContent = undefined;
      if (fileType === 'text' || fileType === 'code') {
        try {
          textContent = fs.readFileSync(fullPath, 'utf-8').slice(0, 5000);
        } catch {
          // ignore error reading
        }
      }

      return {
        id: Buffer.from(itemRelPath).toString('base64'),
        name,
        path: cleanRelPath,
        type: fileType,
        size: isDir ? 0 : stat.size,
        modified: stat.mtime.toISOString(),
        extension: isDir ? '' : path.extname(name).toLowerCase(),
        contentUrl: `/api/download?path=${encodeURIComponent(itemRelPath)}`,
        textContent,
        dimensions: fileType === 'image' ? '1920x1080' : undefined,
        duration: fileType === 'audio' ? 214 : fileType === 'video' ? 1450 : undefined,
      };
    });

    res.json({
      success: true,
      currentPath: cleanRelPath,
      files: result,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error listing directory' });
  }
});

// POST /api/upload
app.post('/api/upload', upload.array('files'), (req: Request, res: Response) => {
  if (serverSettings.readOnly) {
    return res.status(403).json({ error: 'Server is currently in Read-Only mode' });
  }

  const files = req.files as Express.Multer.File[];
  const clientIp = req.ip || '192.168.1.105';

  if (files && files.length > 0) {
    files.forEach(f => {
      transferHistory.unshift({
        id: `tr-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        filename: f.originalname,
        size: f.size,
        bytesTransferred: f.size,
        speedKbps: Math.floor(Math.random() * 8000) + 4000,
        type: 'upload',
        status: 'completed',
        clientIp,
        startTime: new Date().toISOString(),
      });
    });
  }

  res.json({
    success: true,
    message: `${files ? files.length : 0} files uploaded successfully.`,
  });
});

// POST /api/folder - Create Folder
app.post('/api/folder', (req: Request, res: Response) => {
  if (serverSettings.readOnly) {
    return res.status(403).json({ error: 'Server is currently in Read-Only mode' });
  }

  const { currentPath, folderName } = req.body;
  if (!folderName || !folderName.trim()) {
    return res.status(400).json({ error: 'Folder name is required' });
  }

  const cleanRelPath = currentPath || '/';
  const targetDir = path.join(STORAGE_ROOT, cleanRelPath, folderName.trim());

  if (fs.existsSync(targetDir)) {
    return res.status(400).json({ error: 'Folder already exists' });
  }

  fs.mkdirSync(targetDir, { recursive: true });
  res.json({ success: true, message: 'Folder created successfully' });
});

// POST /api/delete - Batch Delete
app.post('/api/delete', (req: Request, res: Response) => {
  if (serverSettings.readOnly) {
    return res.status(403).json({ error: 'Server is currently in Read-Only mode' });
  }

  const { items } = req.body; // array of relative paths, e.g. ["/Pictures/Beach.jpg"]
  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'No items specified for deletion' });
  }

  let deletedCount = 0;
  items.forEach((relPath: string) => {
    const fullPath = path.join(STORAGE_ROOT, relPath);
    if (fs.existsSync(fullPath)) {
      fs.rmSync(fullPath, { recursive: true, force: true });
      deletedCount++;
    }
  });

  res.json({ success: true, message: `${deletedCount} items deleted.` });
});

// POST /api/rename
app.post('/api/rename', (req: Request, res: Response) => {
  if (serverSettings.readOnly) {
    return res.status(403).json({ error: 'Server is currently in Read-Only mode' });
  }

  const { oldRelPath, newName } = req.body;
  if (!oldRelPath || !newName) {
    return res.status(400).json({ error: 'Old path and new name required' });
  }

  const sourcePath = path.join(STORAGE_ROOT, oldRelPath);
  const parentDir = path.dirname(sourcePath);
  const targetPath = path.join(parentDir, newName.trim());

  if (!fs.existsSync(sourcePath)) {
    return res.status(404).json({ error: 'Source file or folder not found' });
  }

  fs.renameSync(sourcePath, targetPath);
  res.json({ success: true, message: 'Renamed successfully' });
});

// GET /api/download
app.get('/api/download', (req: Request, res: Response) => {
  const relPath = (req.query.path as string) || '';
  const fullPath = path.join(STORAGE_ROOT, relPath);

  if (!fs.existsSync(fullPath)) {
    return res.status(404).send('File not found');
  }

  const stat = fs.statSync(fullPath);
  if (stat.isDirectory()) {
    return res.status(400).send('Folder downloading as raw stream is not supported without zipping');
  }

  // Log transfer
  transferHistory.unshift({
    id: `tr-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    filename: path.basename(fullPath),
    size: stat.size,
    bytesTransferred: stat.size,
    speedKbps: Math.floor(Math.random() * 12000) + 6000,
    type: 'download',
    status: 'completed',
    clientIp: req.ip || '192.168.1.140',
    startTime: new Date().toISOString(),
  });

  res.download(fullPath);
});

// GET /api/search?q=keyword
app.get('/api/search', (req: Request, res: Response) => {
  const query = (req.query.q as string || '').toLowerCase().trim();
  if (!query) {
    return res.json({ success: true, results: [] });
  }

  const results: any[] = [];

  function searchRecursive(currentDir: string, relDir: string) {
    if (!fs.existsSync(currentDir)) return;
    const entries = fs.readdirSync(currentDir);
    entries.forEach((name) => {
      const fullPath = path.join(currentDir, name);
      const itemRelPath = relDir === '/' ? `/${name}` : `${relDir}/${name}`;
      const stat = fs.statSync(fullPath);
      const isDir = stat.isDirectory();

      if (name.toLowerCase().includes(query)) {
        const fileType = getFileType(name, isDir);
        results.push({
          id: Buffer.from(itemRelPath).toString('base64'),
          name,
          path: relDir,
          type: fileType,
          size: isDir ? 0 : stat.size,
          modified: stat.mtime.toISOString(),
          extension: isDir ? '' : path.extname(name).toLowerCase(),
          contentUrl: `/api/download?path=${encodeURIComponent(itemRelPath)}`,
        });
      }

      if (isDir) {
        searchRecursive(fullPath, itemRelPath);
      }
    });
  }

  searchRecursive(STORAGE_ROOT, '/');
  res.json({ success: true, query, results });
});

// GET /api/transfers
app.get('/api/transfers', (req: Request, res: Response) => {
  res.json({
    success: true,
    transfers: transferHistory,
  });
});

// Vite & Static file handling
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`WiFi File Explorer Pro Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
