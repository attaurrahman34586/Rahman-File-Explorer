var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_vite = require("vite");
var import_multer = __toESM(require("multer"), 1);
var app = (0, import_express.default)();
var PORT = 3e3;
app.use(import_express.default.json());
app.use(import_express.default.urlencoded({ extended: true }));
app.use(import_express.default.static(import_path.default.join(process.cwd(), "public")));
var STORAGE_ROOT = import_path.default.join(process.cwd(), "wifi_explorer_data");
if (!import_fs.default.existsSync(STORAGE_ROOT)) {
  import_fs.default.mkdirSync(STORAGE_ROOT, { recursive: true });
}
var storage = import_multer.default.diskStorage({
  destination: (req, file, cb) => {
    const relativePath = req.query.path || "/";
    const targetDir = import_path.default.join(STORAGE_ROOT, relativePath);
    if (!import_fs.default.existsSync(targetDir)) {
      import_fs.default.mkdirSync(targetDir, { recursive: true });
    }
    cb(null, targetDir);
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  }
});
var upload = (0, import_multer.default)({ storage });
var lastHeartbeatTime = Date.now();
var appAlive = true;
var serverSettings = {
  ssid: "AndroidAP_Hotspot",
  ipAddress: "192.168.43.1",
  hotspotIp: "192.168.43.1",
  wifiIp: "192.168.1.105",
  port: 8888,
  isServerRunning: true,
  autoStartOnLaunch: true,
  hotspotActive: true,
  connectionType: "hotspot",
  pinProtected: false,
  pinCode: "1234",
  readOnly: false,
  activeClients: 3,
  maxUploadSizeMb: 500
};
var transferHistory = [
  {
    id: "tr-1",
    filename: "Sunset_Goa_4K.jpg",
    size: 485e4,
    bytesTransferred: 485e4,
    speedKbps: 8400,
    type: "upload",
    status: "completed",
    clientIp: "192.168.1.112",
    startTime: new Date(Date.now() - 1e3 * 60 * 12).toISOString()
  },
  {
    id: "tr-2",
    filename: "Project_Presentation.pdf",
    size: 142e5,
    bytesTransferred: 142e5,
    speedKbps: 12500,
    type: "download",
    status: "completed",
    clientIp: "192.168.1.140",
    startTime: new Date(Date.now() - 1e3 * 60 * 5).toISOString()
  }
];
function seedDemoFiles() {
  const folders = [
    "Pictures",
    "Pictures/Vacation 2026",
    "Music",
    "Videos",
    "Documents",
    "Downloads",
    "APKs & Apps",
    "Archives"
  ];
  folders.forEach((folder) => {
    const dir = import_path.default.join(STORAGE_ROOT, folder);
    if (!import_fs.default.existsSync(dir)) {
      import_fs.default.mkdirSync(dir, { recursive: true });
    }
  });
  const sampleFiles = [
    {
      dir: "Pictures",
      name: "Wallpaper_Nature.jpg",
      content: "Demo Image Content",
      type: "image"
    },
    {
      dir: "Pictures/Vacation 2026",
      name: "Beach_Sunset.jpg",
      content: "Demo Beach Photo",
      type: "image"
    },
    {
      dir: "Pictures/Vacation 2026",
      name: "Mountain_Trek.png",
      content: "Demo Mountain Photo",
      type: "image"
    },
    {
      dir: "Music",
      name: "Acoustic_Guitar_Vibes.mp3",
      content: "Demo MP3 Audio Stream Data",
      type: "audio"
    },
    {
      dir: "Music",
      name: "LoFi_Study_Beat.flac",
      content: "Demo LoFi Audio Stream Data",
      type: "audio"
    },
    {
      dir: "Videos",
      name: "Drone_4K_Nature_Tour.mp4",
      content: "Demo Video File Stream",
      type: "video"
    },
    {
      dir: "Documents",
      name: "WiFi_Explorer_Guide.pdf",
      content: "WiFi File Explorer Pro - User Guide & Setup Manual.\nConnect wirelessly over local Wi-Fi network without cables.",
      type: "document"
    },
    {
      dir: "Documents",
      name: "Meeting_Notes_July.txt",
      content: "# Team Sync - July 2026\n- Wi-Fi Transfer Speed tested at 45 MB/s\n- QR code quick scanner added\n- Multi-file drag and drop enabled.",
      type: "text"
    },
    {
      dir: "Downloads",
      name: "Setup_Package_v2.4.zip",
      content: "Demo Zip Archive File",
      type: "archive"
    },
    {
      dir: "APKs & Apps",
      name: "WiFiFileExplorerPro_v4.2.apk",
      content: "Demo Android Package File",
      type: "app"
    }
  ];
  sampleFiles.forEach((file) => {
    const filePath = import_path.default.join(STORAGE_ROOT, file.dir, file.name);
    if (!import_fs.default.existsSync(filePath)) {
      import_fs.default.writeFileSync(filePath, file.content, "utf-8");
    }
  });
}
seedDemoFiles();
function getFileType(filename, isDirectory) {
  if (isDirectory) return "folder";
  const ext = import_path.default.extname(filename).toLowerCase();
  if ([".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg", ".bmp"].includes(ext)) return "image";
  if ([".mp4", ".mkv", ".avi", ".webm", ".mov", ".3gp"].includes(ext)) return "video";
  if ([".mp3", ".wav", ".ogg", ".flac", ".m4a", ".aac"].includes(ext)) return "audio";
  if ([".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt"].includes(ext)) {
    return ext === ".txt" ? "text" : "document";
  }
  if ([".zip", ".rar", ".7z", ".tar", ".gz"].includes(ext)) return "archive";
  if ([".apk", ".xapk"].includes(ext)) return "app";
  if ([".json", ".js", ".ts", ".html", ".css", ".md", ".py", ".java"].includes(ext)) return "code";
  return "document";
}
app.post("/api/heartbeat", (req, res) => {
  lastHeartbeatTime = Date.now();
  appAlive = true;
  serverSettings.isServerRunning = true;
  res.json({ success: true, isServerRunning: serverSettings.isServerRunning, hotspotActive: serverSettings.hotspotActive });
});
app.post("/api/app-close", (req, res) => {
  appAlive = false;
  serverSettings.isServerRunning = false;
  console.log("App closed or cleared from Recent Apps - WiFi File Explorer Server Stopped.");
  res.json({ success: true, message: "Server and app stopped." });
});
app.get("/api/download-zip", (req, res) => {
  const zipPath = import_path.default.join(process.cwd(), "public", "rahman-file-explorer.zip");
  if (import_fs.default.existsSync(zipPath)) {
    res.download(zipPath, "rahman-file-explorer.zip");
  } else {
    res.status(404).json({ error: "ZIP file not generated yet" });
  }
});
app.post("/api/hotspot-toggle", (req, res) => {
  const { active, ssid } = req.body;
  if (active !== void 0) serverSettings.hotspotActive = Boolean(active);
  if (ssid) serverSettings.ssid = ssid;
  if (serverSettings.hotspotActive) {
    serverSettings.ipAddress = serverSettings.hotspotIp;
  } else {
    serverSettings.ipAddress = serverSettings.wifiIp;
  }
  res.json({ success: true, settings: serverSettings });
});
app.get("/api/status", (req, res) => {
  res.json({
    success: true,
    settings: serverSettings,
    storage: {
      totalBytes: 64 * 1024 * 1024 * 1024,
      // 64 GB
      usedBytes: 28.4 * 1024 * 1024 * 1024,
      // 28.4 GB
      freeBytes: 35.6 * 1024 * 1024 * 1024,
      // 35.6 GB
      categories: {
        images: 12.2 * 1024 * 1024 * 1024,
        videos: 9.8 * 1024 * 1024 * 1024,
        audio: 3.4 * 1024 * 1024 * 1024,
        documents: 1.2 * 1024 * 1024 * 1024,
        archives: 1.1 * 1024 * 1024 * 1024,
        apps: 0.7 * 1024 * 1024 * 1024,
        others: 0 * 1024 * 1024 * 1024
      }
    }
  });
});
app.post("/api/settings", (req, res) => {
  const { ssid, pinProtected, pinCode, readOnly, isServerRunning, hotspotActive, port, connectionType } = req.body;
  if (ssid !== void 0) serverSettings.ssid = ssid;
  if (pinProtected !== void 0) serverSettings.pinProtected = Boolean(pinProtected);
  if (pinCode !== void 0) serverSettings.pinCode = String(pinCode);
  if (readOnly !== void 0) serverSettings.readOnly = Boolean(readOnly);
  if (isServerRunning !== void 0) serverSettings.isServerRunning = Boolean(isServerRunning);
  if (hotspotActive !== void 0) serverSettings.hotspotActive = Boolean(hotspotActive);
  if (port !== void 0) serverSettings.port = Number(port);
  if (connectionType !== void 0) serverSettings.connectionType = connectionType;
  res.json({ success: true, settings: serverSettings });
});
function checkHotspotAndServer(req, res, next) {
  if (!serverSettings.isServerRunning) {
    return res.status(503).json({ error: "Server is currently stopped. Reopen app to start server." });
  }
  if (!serverSettings.hotspotActive) {
    return res.status(503).json({ error: "Hotspot is OFF. Hotspot must be enabled to serve files wirelessly." });
  }
  next();
}
app.get("/api/files", checkHotspotAndServer, (req, res) => {
  try {
    const relPath = req.query.path || "/";
    const cleanRelPath = relPath.startsWith("/") ? relPath : "/" + relPath;
    const targetDir = import_path.default.normalize(import_path.default.join(STORAGE_ROOT, cleanRelPath));
    if (!targetDir.startsWith(STORAGE_ROOT)) {
      return res.status(403).json({ error: "Access denied: Path outside root" });
    }
    if (!import_fs.default.existsSync(targetDir)) {
      return res.status(404).json({ error: "Directory not found" });
    }
    const items = import_fs.default.readdirSync(targetDir);
    const result = items.map((name) => {
      const fullPath = import_path.default.join(targetDir, name);
      const stat = import_fs.default.statSync(fullPath);
      const isDir = stat.isDirectory();
      const fileType = getFileType(name, isDir);
      const itemRelPath = cleanRelPath === "/" ? `/${name}` : `${cleanRelPath}/${name}`;
      let textContent = void 0;
      if (fileType === "text" || fileType === "code") {
        try {
          textContent = import_fs.default.readFileSync(fullPath, "utf-8").slice(0, 5e3);
        } catch {
        }
      }
      return {
        id: Buffer.from(itemRelPath).toString("base64"),
        name,
        path: cleanRelPath,
        type: fileType,
        size: isDir ? 0 : stat.size,
        modified: stat.mtime.toISOString(),
        extension: isDir ? "" : import_path.default.extname(name).toLowerCase(),
        contentUrl: `/api/download?path=${encodeURIComponent(itemRelPath)}`,
        textContent,
        dimensions: fileType === "image" ? "1920x1080" : void 0,
        duration: fileType === "audio" ? 214 : fileType === "video" ? 1450 : void 0
      };
    });
    res.json({
      success: true,
      currentPath: cleanRelPath,
      files: result
    });
  } catch (err) {
    res.status(500).json({ error: err.message || "Error listing directory" });
  }
});
app.post("/api/upload", upload.array("files"), (req, res) => {
  if (serverSettings.readOnly) {
    return res.status(403).json({ error: "Server is currently in Read-Only mode" });
  }
  const files = req.files;
  const clientIp = req.ip || "192.168.1.105";
  if (files && files.length > 0) {
    files.forEach((f) => {
      transferHistory.unshift({
        id: `tr-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        filename: f.originalname,
        size: f.size,
        bytesTransferred: f.size,
        speedKbps: Math.floor(Math.random() * 8e3) + 4e3,
        type: "upload",
        status: "completed",
        clientIp,
        startTime: (/* @__PURE__ */ new Date()).toISOString()
      });
    });
  }
  res.json({
    success: true,
    message: `${files ? files.length : 0} files uploaded successfully.`
  });
});
app.post("/api/folder", (req, res) => {
  if (serverSettings.readOnly) {
    return res.status(403).json({ error: "Server is currently in Read-Only mode" });
  }
  const { currentPath, folderName } = req.body;
  if (!folderName || !folderName.trim()) {
    return res.status(400).json({ error: "Folder name is required" });
  }
  const cleanRelPath = currentPath || "/";
  const targetDir = import_path.default.join(STORAGE_ROOT, cleanRelPath, folderName.trim());
  if (import_fs.default.existsSync(targetDir)) {
    return res.status(400).json({ error: "Folder already exists" });
  }
  import_fs.default.mkdirSync(targetDir, { recursive: true });
  res.json({ success: true, message: "Folder created successfully" });
});
app.post("/api/delete", (req, res) => {
  if (serverSettings.readOnly) {
    return res.status(403).json({ error: "Server is currently in Read-Only mode" });
  }
  const { items } = req.body;
  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: "No items specified for deletion" });
  }
  let deletedCount = 0;
  items.forEach((relPath) => {
    const fullPath = import_path.default.join(STORAGE_ROOT, relPath);
    if (import_fs.default.existsSync(fullPath)) {
      import_fs.default.rmSync(fullPath, { recursive: true, force: true });
      deletedCount++;
    }
  });
  res.json({ success: true, message: `${deletedCount} items deleted.` });
});
app.post("/api/rename", (req, res) => {
  if (serverSettings.readOnly) {
    return res.status(403).json({ error: "Server is currently in Read-Only mode" });
  }
  const { oldRelPath, newName } = req.body;
  if (!oldRelPath || !newName) {
    return res.status(400).json({ error: "Old path and new name required" });
  }
  const sourcePath = import_path.default.join(STORAGE_ROOT, oldRelPath);
  const parentDir = import_path.default.dirname(sourcePath);
  const targetPath = import_path.default.join(parentDir, newName.trim());
  if (!import_fs.default.existsSync(sourcePath)) {
    return res.status(404).json({ error: "Source file or folder not found" });
  }
  import_fs.default.renameSync(sourcePath, targetPath);
  res.json({ success: true, message: "Renamed successfully" });
});
app.get("/api/download", (req, res) => {
  const relPath = req.query.path || "";
  const fullPath = import_path.default.join(STORAGE_ROOT, relPath);
  if (!import_fs.default.existsSync(fullPath)) {
    return res.status(404).send("File not found");
  }
  const stat = import_fs.default.statSync(fullPath);
  if (stat.isDirectory()) {
    return res.status(400).send("Folder downloading as raw stream is not supported without zipping");
  }
  transferHistory.unshift({
    id: `tr-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    filename: import_path.default.basename(fullPath),
    size: stat.size,
    bytesTransferred: stat.size,
    speedKbps: Math.floor(Math.random() * 12e3) + 6e3,
    type: "download",
    status: "completed",
    clientIp: req.ip || "192.168.1.140",
    startTime: (/* @__PURE__ */ new Date()).toISOString()
  });
  res.download(fullPath);
});
app.get("/api/search", (req, res) => {
  const query = (req.query.q || "").toLowerCase().trim();
  if (!query) {
    return res.json({ success: true, results: [] });
  }
  const results = [];
  function searchRecursive(currentDir, relDir) {
    if (!import_fs.default.existsSync(currentDir)) return;
    const entries = import_fs.default.readdirSync(currentDir);
    entries.forEach((name) => {
      const fullPath = import_path.default.join(currentDir, name);
      const itemRelPath = relDir === "/" ? `/${name}` : `${relDir}/${name}`;
      const stat = import_fs.default.statSync(fullPath);
      const isDir = stat.isDirectory();
      if (name.toLowerCase().includes(query)) {
        const fileType = getFileType(name, isDir);
        results.push({
          id: Buffer.from(itemRelPath).toString("base64"),
          name,
          path: relDir,
          type: fileType,
          size: isDir ? 0 : stat.size,
          modified: stat.mtime.toISOString(),
          extension: isDir ? "" : import_path.default.extname(name).toLowerCase(),
          contentUrl: `/api/download?path=${encodeURIComponent(itemRelPath)}`
        });
      }
      if (isDir) {
        searchRecursive(fullPath, itemRelPath);
      }
    });
  }
  searchRecursive(STORAGE_ROOT, "/");
  res.json({ success: true, query, results });
});
app.get("/api/transfers", (req, res) => {
  res.json({
    success: true,
    transfers: transferHistory
  });
});
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`WiFi File Explorer Pro Server running on http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
