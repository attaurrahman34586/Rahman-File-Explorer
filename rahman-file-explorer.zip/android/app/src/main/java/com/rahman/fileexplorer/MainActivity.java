package com.rahman.fileexplorer;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
